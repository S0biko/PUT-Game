#include "Waves.h"

void spawnWave(int waveSize, std::vector<MonsterSprite>& activeZombies, const sf::Texture& zombieTexture) {
    for (int i = 0; i < waveSize; ++i) {
        MonsterSprite zombie(zombiePhoto);
        zombie.setTexture(zombieTexture);
        zombie.add_animation_frame(sf::IntRect(5, 70, 26, 29));
        zombie.add_animation_frame(sf::IntRect(35, 70, 26, 29));
        zombie.add_animation_frame(sf::IntRect(66, 70, 26, 29));
        zombie.add_animation_frame(sf::IntRect(100, 70, 26, 29));
        zombie.add_animation_frame(sf::IntRect(133, 70, 26, 29));
        zombie.add_animation_frame(sf::IntRect(166, 70, 26, 29));
        zombie.add_animation_frame(sf::IntRect(196, 70, 26, 29));

        float x = static_cast<float>(std::rand() % windowX);
        float y = static_cast<float>(std::rand() % windowY);
        zombie.setPosition(x, y);
        activeZombies.push_back(zombie);
    }
}

void displayCenteredText(sf::RenderWindow& window, const std::string& text, const sf::Font& font, unsigned int size, const sf::Color& color, float duration) {
    sf::Text displayText;
    displayText.setFont(font);
    displayText.setString(text);
    displayText.setCharacterSize(size);
    displayText.setFillColor(color);

    sf::FloatRect textRect = displayText.getLocalBounds();
    displayText.setOrigin(textRect.width / 2, textRect.height / 2);
    displayText.setPosition(window.getSize().x / 2.0f, window.getSize().y / 2.0f);

    sf::Clock clock;
    while (clock.getElapsedTime().asSeconds() < duration) {
        window.clear(sf::Color::Black);
        window.draw(displayText);
        window.display();
    }
}
