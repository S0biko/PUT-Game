#include "Knife.h"
#include <cmath>
#include <iostream>

// Implementacja klasy Knife
Knife::Knife(const std::string& path, const sf::Vector2f& iconPosition, sf::RenderWindow& window, const sf::Font& font)
    : Weapon(path), window_(window), active_(false), ready_(true), cooldown_(1.0f), duration_(5.0f)
{
    if (!texture_.loadFromFile(path)) {
        std::cerr << "Could not load texture: " << path << std::endl;
    } else {
        setTexture(texture_);
    }

    setScale(0.1f, 0.1f); // Zmniejszenie wielkości noża

    icon_.setTexture(texture_);
    icon_.setTextureRect(sf::IntRect(40, 68, 400, 400)); // First frame of knife animation (if available)
    icon_.setScale(0.1f, 0.1f); // Adjust the scale if needed
    icon_.setPosition(iconPosition);

    cooldownText_.setFont(font);
    cooldownText_.setCharacterSize(15);
    cooldownText_.setFillColor(sf::Color::Red);
    cooldownText_.setPosition(iconPosition.x, iconPosition.y + 40); // Pozycjonowanie tekstu pod ikoną
}

void Knife::MoveIt(const sf::Time &elapsed)
{
    float dt = elapsed.asSeconds();
    move(speed_x * dt, speed_y * dt);
}

void Knife::setDirection(const sf::Vector2f& targetPosition)
{
    sf::Vector2f direction = targetPosition - getPosition();
    float length = std::sqrt(direction.x * direction.x + direction.y * direction.y);
    direction /= length;
    speed_x = direction.x * 250;
    speed_y = direction.y * 250;
    float rotation = std::atan2(direction.y, direction.x) * 180.f / static_cast<float>(M_PI);
    setRotation(rotation);
}

void Knife::resetPosition(const sf::Vector2f& startPosition)
{
    setPosition(startPosition);
    // Ponownie ustaw kierunek na gracza
    speed_x = 500 * direction_.x;
    speed_y = 500 * direction_.y;
}

void Knife::activate(const sf::Vector2f& startPosition, const sf::Vector2f& targetPosition)
{
    if (ready_) {
        active_ = true;
        ready_ = false;
        knifeClock_.restart();
        setPosition(startPosition); // Ustaw pozycję początkową noża na pozycję gracza
        setDirection(targetPosition); // Ustaw kierunek w stronę kursora
    }
}

void Knife::update(const sf::Time &elapsed, const sf::Vector2f& playerPosition, const sf::Vector2f& mousePosition)
{
    sf::Time knifeElapsed = knifeClock_.getElapsedTime();

    if (active_) {
        MoveIt(elapsed);
        window_.draw(*this);
        if (knifeElapsed.asSeconds() >= duration_) {
            active_ = false;
            reset();
        }
    }

    if (knifeElapsed.asSeconds() >= cooldown_) {
        ready_ = true;
    }

    if (!ready_) {
        float cooldownTimeLeft = cooldown_ - knifeElapsed.asSeconds();
        cooldownText_.setString(std::to_string(cooldownTimeLeft).substr(0, 4));
        icon_.setColor(sf::Color(255, 255, 255, 128));
    } else {
        cooldownText_.setString("");
        icon_.setColor(sf::Color(255, 255, 255, 255));
    }

    drawIcon();
}

void Knife::reset()
{
    setPosition(-100, -100);
    active_ = false;
}

bool Knife::isReady() const
{
    return ready_;
}

bool Knife::isActive() const
{
    return active_;
}

void Knife::drawIcon()
{
    window_.draw(icon_);
    window_.draw(cooldownText_);
}
