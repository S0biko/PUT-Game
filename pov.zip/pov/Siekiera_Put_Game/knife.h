#ifndef KNIFE_H
#define KNIFE_H

#include "Weapon.h"
#include <SFML/Graphics.hpp>

class Knife : public Weapon
{
public:
    Knife(const std::string& path, const sf::Vector2f& iconPosition, sf::RenderWindow& window, const sf::Font& font);
    void MoveIt(const sf::Time &elapsed);
    void setDirection(const sf::Vector2f& targetPosition);
    void resetPosition(const sf::Vector2f& startPosition);
    void activate(const sf::Vector2f& startPosition, const sf::Vector2f& targetPosition);
    void update(const sf::Time &elapsed, const sf::Vector2f& playerPosition, const sf::Vector2f& mousePosition);
    bool isReady() const;
    bool isActive() const;
    void drawIcon();
    void reset();


private:
    float speed_x = 100.0f; // Przykładowe wartości, możesz je zmienić
    float speed_y = 100.0f;
    sf::Vector2f direction_;
    sf::RenderWindow& window_;
    sf::Sprite icon_;
    sf::Text cooldownText_;
    sf::Clock knifeClock_;
    bool active_;
    bool ready_;
    float cooldown_;
    float duration_;

};

#endif // KNIFE_H
