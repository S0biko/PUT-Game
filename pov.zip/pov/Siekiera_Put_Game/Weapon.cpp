#include "Weapon.h"
#include <iostream>

// Implementacja klasy Weapon
Weapon::Weapon(const std::string& path)
{
    if (!texture_.loadFromFile(path)){
        std::cerr << "Could not load texture: " << path << std::endl;
    } else {
        setTexture(texture_);
    }
    setScale(1, 1); // Ustaw skalę na domyślną wartość
}

void Weapon::setTexture(const sf::Texture& texture)
{
    texture_ = texture;
    sf::Sprite::setTexture(texture_);
}
