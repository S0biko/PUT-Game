#include "Menu.h"
#include <iostream>

void Game_over(int wynik, bool& playAgain, bool& goToMainMenu, const std::string& fontPhoto) {
    sf::RenderWindow window_over(sf::VideoMode(500, 500), "Game over");
    sf::Font font;
    if (!font.loadFromFile(fontPhoto)) {
        std::cerr << "Could not load font: " << fontPhoto << std::endl;
        return;
    }

    sf::Text title("Game over", font, 50);
    title.setFillColor(sf::Color::White);
    title.setPosition(120, 100);

    std::string napis = "Twoj wynik to " + std::to_string(wynik);
    sf::Text wynik_napis(napis, font, 30);
    wynik_napis.setFillColor(sf::Color::White);
    wynik_napis.setPosition(120, 200);

    sf::Text playAgainText("Play Again", font, 30);
    playAgainText.setFillColor(sf::Color::White);
    playAgainText.setPosition(180, 300);

    sf::Text exitText("Main Menu", font, 30);
    exitText.setFillColor(sf::Color::White);
    exitText.setPosition(180, 350);

    while (window_over.isOpen())
    {
        sf::Event event;
        while (window_over.pollEvent(event))
        {
            if (event.type == sf::Event::Closed)
            {
                window_over.close();
            }

            if (event.type == sf::Event::MouseButtonPressed) {
                sf::Vector2i mousePos = sf::Mouse::getPosition(window_over);
                if (mousePos.x >= 180 && mousePos.x <= 320 && mousePos.y >= 300 && mousePos.y <= 330) {
                    playAgain = true;
                    window_over.close();
                }
                if (mousePos.x >= 180 && mousePos.x <= 320 && mousePos.y >= 350 && mousePos.y <= 380) {
                    goToMainMenu = true;
                    window_over.close();
                }
            }
        }

        window_over.clear();
        window_over.draw(title);
        window_over.draw(wynik_napis);
        window_over.draw(playAgainText);
        window_over.draw(exitText);
        window_over.display();
    }
}

void displayMainMenu(sf::RenderWindow& window, const sf::Font& font, bool& startGame, bool& exitGame, std::string& gameMode) {
    sf::Text title("Main Menu", font, 50);
    title.setFillColor(sf::Color::White);
    title.setPosition(150, 100);

    sf::Text clearModeText("Clear Mode", font, 30);
    clearModeText.setFillColor(sf::Color::White);
    clearModeText.setPosition(180, 200);

    sf::Text mazeModeText("Maze Mode", font, 30);
    mazeModeText.setFillColor(sf::Color::White);
    mazeModeText.setPosition(180, 250);

    sf::Text exitText("Exit", font, 30);
    exitText.setFillColor(sf::Color::White);
    exitText.setPosition(180, 300);

    while (window.isOpen())
    {
        sf::Event event;
        while (window.pollEvent(event))
        {
            if (event.type == sf::Event::Closed)
            {
                window.close();
                exitGame = true;
            }

            if (event.type == sf::Event::MouseButtonPressed) {
                sf::Vector2i mousePos = sf::Mouse::getPosition(window);
                if (mousePos.x >= 180 && mousePos.x <= 320 && mousePos.y >= 200 && mousePos.y <= 230) {
                    startGame = true;
                    gameMode = "clear";
                    window.close();
                }
                if (mousePos.x >= 180 && mousePos.x <= 320 && mousePos.y >= 250 && mousePos.y <= 280) {
                    startGame = true;
                    gameMode = "maze";
                    window.close();
                }
                if (mousePos.x >= 180 && mousePos.x <= 320 && mousePos.y >= 300 && mousePos.y <= 330) {
                    exitGame = true;
                    window.close();
                }
            }
        }

        window.clear();
        window.draw(title);
        window.draw(clearModeText);
        window.draw(mazeModeText);
        window.draw(exitText);
        window.display();
    }
}
