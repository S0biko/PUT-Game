#include "displayBoundingBox.h"

void displayBoundingBox(const sf::Sprite& sprite, sf::RenderWindow& window)
{
    sf::FloatRect bounds = sprite.getGlobalBounds();

    sf::RectangleShape boundingBox;
    boundingBox.setSize(sf::Vector2f(bounds.width, bounds.height));
    boundingBox.setOutlineThickness(2.f);
    boundingBox.setOutlineColor(sf::Color::Blue);
    boundingBox.setFillColor(sf::Color::Transparent);
    boundingBox.setPosition(bounds.left, bounds.top);

    window.draw(boundingBox);
}
