#include <iostream>
#include <vector>
#include <cmath>
#include <cstdlib>
#include <SFML/Window.hpp>
#include <SFML/Graphics.hpp>
// Funkcje globalne
#include <Global.h>
// Funkcje Postaci
#include <CharacterSprite.h>
// Funkcje broni
#include "Weapon.h"
#include "Knife.h"
#include "Fireball.h"
#include "Axe.h"
// Inne funkcje
#include <livefunc.h>
#include <Health.h>

void runHealthExample();

// __________________________________Obrysy_____________________
void displayBoundingBox(const sf::Sprite& sprite, sf::RenderWindow& window)
{
    sf::FloatRect bounds = sprite.getGlobalBounds();

    sf::RectangleShape boundingBox;
    boundingBox.setSize(sf::Vector2f(bounds.width, bounds.height));
    boundingBox.setOutlineThickness(2.f);
    boundingBox.setOutlineColor(sf::Color::Blue);
    boundingBox.setFillColor(sf::Color::Transparent);
    boundingBox.setPosition(bounds.left, bounds.top);

    // window.draw(boundingBox);
}

// _____________________________MAIN_________________________________________
int main()
{
    sf::RenderWindow window(sf::VideoMode(windowX, windowY), "PutGame");
    sf::Clock clock;

    // Ładowanie tekstury ściany
    sf::Texture texture_wall;
    if (!texture_wall.loadFromFile(backgroundPhoto)) {
        std::cerr << "Could not load texture: " << backgroundPhoto << std::endl;
        return 1;
    }
    texture_wall.setRepeated(true);  // Ustawienie powtarzania tekstury

    // Ładowanie tekstury noża
    sf::Texture knife_texture;
    if (!knife_texture.loadFromFile(knifePhoto)) {
        std::cerr << "Could not load texture: " << knifePhoto << std::endl;
        return 1;
    } else {
        std::cout << "Knife texture loaded successfully." << std::endl;
    }

    HeroSpriteWithCollision guy(characterPhoto);
    guy.add_animation_frame_stand(sf::IntRect(15, 6, 22, 30)); // hero standing frame 1
    guy.add_animation_frame_stand(sf::IntRect(65, 6, 22, 30)); // hero standing frame 2
    guy.add_animation_frame_stand(sf::IntRect(115, 6, 22, 30)); // hero standing frame 3
    guy.add_animation_frame(sf::IntRect(165, 6, 22, 30)); // hero running frame 1
    guy.add_animation_frame(sf::IntRect(215, 6, 22, 30)); // hero running frame 2
    guy.add_animation_frame(sf::IntRect(265, 6, 22, 30)); // hero running frame 3
    guy.add_animation_frame(sf::IntRect(315, 6, 22, 30)); // hero running frame 4
    guy.add_animation_frame(sf::IntRect(365, 6, 22, 30)); // hero running frame 5
    guy.add_animation_frame(sf::IntRect(415, 6, 22, 30)); // hero running frame 6

    guy.setBounds(0, window.getSize().x, 0, window.getSize().y);

    std::cout << "Window size: " << window.getSize().x << ", " << window.getSize().y << std::endl;
    std::cout << "Main function - Bounds after setting texture rect: " << guy.getGlobalBounds().left << ", " << guy.getGlobalBounds().top << ", "
              << guy.getGlobalBounds().width << ", " << guy.getGlobalBounds().height << std::endl;

    sf::Sprite grass;
    grass.setTexture(texture_wall);
    grass.setScale(1.5, 1.5);
    grass.setTextureRect(sf::IntRect(0, 0, 1500, 1500));
    std::vector<sf::Sprite> walls;

    bool IsAxe = true;
    bool IsFireb = false;

    std::vector<Knife> knives; // Wektor przechowujący noże
    Axe axe(axePhoto);
    Fireball fireb(fireballPhoto);
    fireb.add_animation_frame(sf::IntRect(40, 68, 400, 400));
    fireb.add_animation_frame(sf::IntRect(540, 68, 400, 400));
    fireb.add_animation_frame(sf::IntRect(1040, 68, 400, 400));
    fireb.add_animation_frame(sf::IntRect(1540, 68, 400, 400));
    fireb.add_animation_frame(sf::IntRect(2040, 68, 400, 400));
    fireb.add_animation_frame(sf::IntRect(2540, 68, 400, 400));

    MonsterSprite zombie(zombiePhoto);
    zombie.add_animation_frame(sf::IntRect(5, 70, 26, 29));
    zombie.add_animation_frame(sf::IntRect(35, 70, 26, 29));
    zombie.add_animation_frame(sf::IntRect(66, 70, 26, 29));
    zombie.add_animation_frame(sf::IntRect(100, 70, 26, 29));
    zombie.add_animation_frame(sf::IntRect(133, 70, 26, 29));
    zombie.add_animation_frame(sf::IntRect(166, 70, 26, 29));
    zombie.add_animation_frame(sf::IntRect(196, 70, 26, 29));
    std::vector<MonsterSprite> sprites;

    std::vector<serce> hearts;
    serce heart1(hearthPhoto);
    serce heart2(hearthPhoto);
    serce heart3(hearthPhoto);
    serce heart4(hearthPhoto);
    serce heart5(hearthPhoto);

    heart1.setPosition(600, 10);
    heart2.setPosition(630, 10);
    heart3.setPosition(660, 10);
    heart4.setPosition(690, 10);
    heart5.setPosition(720, 10);

    hearts.push_back(heart1);
    hearts.push_back(heart2);
    hearts.push_back(heart3);
    hearts.push_back(heart4);
    hearts.push_back(heart5);

    sf::Font font;
    if (!font.loadFromFile(fontPhoto)) {
        // Error handling - Failed to load the font
    }

    sf::Text scoreText;
    scoreText.setFont(font);
    scoreText.setCharacterSize(30);
    scoreText.setFillColor(sf::Color::White);
    scoreText.setPosition(340, 10);

    sf::Text ExitText;
    ExitText.setFont(font);
    ExitText.setCharacterSize(15);
    ExitText.setFillColor(sf::Color::White);
    ExitText.setPosition(20, 10);
    std::string exitString = "Press Esc to SHOUTDOWN";

    while (window.isOpen())
    {
        sf::Time elapsed = clock.restart();

        float dt = elapsed.asSeconds();
        static float counter_fireb = 0;
        static float counter_knife = 0;
        static float counter = 0;
        static float counter_lives = 0;

        counter += dt;
        counter_fireb += dt;
        counter_knife += dt;
        counter_lives += dt;

        if (counter > 1.0) {
            sprites.push_back(zombie);
            zombie.die_monster(guy.getPosition(), 600);
            counter = 0;
        }

        if (counter_fireb > 3.0 && !IsFireb) {
            fireb.setScale(0.2, 0.2);
            float angle = static_cast<float>(std::rand()) / static_cast<float>(RAND_MAX) * 2 * M_PI;
            IsFireb = true;
            counter_fireb = 0;
            fireb.setPosition(guy.getPosition());
            speed_x_fb = 250 * cos(angle);
            speed_y_fb = 250 * sin(angle);
            float rotation = std::atan2(sin(angle), cos(angle)) * 180.f / static_cast<float>(M_PI);
            fireb.setRotation(rotation);
        }

        if (counter_knife > 0.5) {
            Knife knife(knifePhoto);
            knife.setTexture(knife_texture); // Ustawienie tekstury noża
            knife.setPosition(guy.getPosition());
            knife.setDirection(guy.getDirection());
            knives.push_back(knife); // Dodanie nowego noża do wektora
            std::cout << "Knife position: " << knife.getPosition().x << ", " << knife.getPosition().y << std::endl;
            counter_knife = 0;
        }

        sf::Event event;
        while (window.pollEvent(event))
        {
            if (event.type == sf::Event::Closed)
            {
                std::cout << "Closing Window" << std::endl;
                window.close();
            }
            if (event.type == sf::Event::KeyPressed && event.key.code == sf::Keyboard::Escape)
            {
                std::cout << "Closing Window" << std::endl;
                window.close();
            }
        }

        sf::FloatRect guy_bounds = guy.getGlobalBounds();
        bool currentIntersection = false;

        sf::Vector2f position;
        sf::FloatRect axe_bounds = axe.getGlobalBounds();
        sf::FloatRect fireball_bounds = fireb.getGlobalBounds();

        // Rysowanie i poruszanie nożami
        for (auto& knife : knives)
        {
            knife.MoveIt(elapsed);
        }

        // Usuwanie noży, które wyszły poza ekran
        knives.erase(std::remove_if(knives.begin(), knives.end(), [&](Knife& knife) {
                         sf::Vector2f knife_pos = knife.getPosition();
                         return knife_pos.x < 0.f || knife_pos.y < 0.f ||
                                knife_pos.x > window.getSize().x || knife_pos.y > window.getSize().y;
                     }), knives.end());

        guy.setBounds(0, window.getSize().x, 0, window.getSize().y);

        guy.moveInDirection(elapsed, walls);

        window.clear(sf::Color::Black);
        window.draw(grass);
        window.draw(guy);
        for (auto &heart : hearts)
        {
            window.draw(heart);
        }

        for (auto& knife : knives)
        {
            window.draw(knife);
            displayBoundingBox(knife, window);
        }

        fireb.MoveIt(elapsed);
        fireb.animate(elapsed);

        if (IsAxe)
        {
            axe.setPosition(guy.getPosition());
            window.draw(axe);
            axe.rotate(0.01);
        }

        if (IsFireb)
        {
            window.draw(fireb);
        }

        displayBoundingBox(guy, window);
        displayBoundingBox(fireb, window);
        displayBoundingBox(axe, window);

        for (auto& sprite : sprites)
        {
            sf::FloatRect monster_bounds = sprite.getGlobalBounds();
            if (monster_bounds.intersects(guy_bounds) && counter_lives > 1.0)
            {
                currentIntersection = true;
                counter_lives = 0;
            }

            if (currentIntersection && !intersectionOccurred)
            {
                intersectionOccurred = true;

                if (healthEnd < healthVar)
                {
                    hearts[healthEnd].setScale(0, 0);
                    healthEnd++;
                }

                if (healthEnd == healthVar)
                {
                    std::cout << "Twoj wynik to: " << Score << " ";
                    window.close();
                }
            }
            else if (!currentIntersection)
            {
                intersectionOccurred = false;
            }

            for (auto& knife : knives)
            {
                sf::FloatRect knife_bounds = knife.getGlobalBounds();
                if (monster_bounds.intersects(knife_bounds))
                {
                    Score += knifeScore;
                    sprite.die_monster(guy.getPosition(), 400);
                    knife.setPosition(-100, -100); // Przenieś nóż poza ekran, aby go usunąć później
                }
            }

            if (monster_bounds.intersects(fireball_bounds))
            {
                Score += fireballScore;
                sprite.die_monster(guy.getPosition(), 400);
            }

            if (monster_bounds.intersects(axe_bounds))
            {
                Score += axeScore;
                sprite.die_monster(guy.getPosition(), 400);
            }

            sprite.setPlayerPosition(guy.getPosition());
            sprite.followPlayer(dt);
            sprite.animate(elapsed);
            displayBoundingBox(sprite, window);
            window.draw(sprite);
        }

        std::string scoreString = "Wynik: " + std::to_string(Score);
        scoreText.setString(scoreString);
        window.draw(scoreText);

        ExitText.setString(exitString);
        window.draw(ExitText);

        window.display();
    }

    return 0;
}
