#ifndef HEADER_H
#define HEADER_H

#endif // HEADER_H
//Funkcja sprawdzająca poprawność wyświetlania tekstur;
