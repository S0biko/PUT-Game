#ifndef AXE_H
#define AXE_H

#include "Weapon.h"

class Axe : public Weapon
{
public:
    Axe(const std::string& path);
};

#endif // AXE_H
