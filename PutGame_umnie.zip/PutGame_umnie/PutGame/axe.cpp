#include "Axe.h"

// Implementacja klasy Axe
Axe::Axe(const std::string& path) : Weapon(path)
{
    setOrigin(400, 400); // Poprawne położenie pochodzenia
    setScale(0.2f, 0.2f);
}
