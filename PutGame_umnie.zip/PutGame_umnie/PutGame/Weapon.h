#ifndef WEAPON_H
#define WEAPON_H

#include <SFML/Graphics.hpp>
#include <vector>

class Weapon : public sf::Sprite
{
protected:
    sf::Texture texture_;

public:
    Weapon(const std::string& path);
    void setTexture(const sf::Texture& texture);  // Deklaracja funkcji
};

class WeaponSprite : public Weapon
{
public:
    WeaponSprite(const std::string& path);
    void MoveIt(const sf::Time &elapsed);
    void setDirection(const sf::Vector2f& direction);

private:
    float speed_x = 100.0f; // Przykładowe wartości, możesz je zmienić
    float speed_y = 100.0f;
    sf::Vector2f direction_;
};

class AxeSprite : public Weapon
{
public:
    AxeSprite(const std::string& path);
};

class FireballSprite : public Weapon
{
private:
    float t_ = 0.0f;
    std::vector<sf::IntRect> rectVector;
    unsigned int fragments_index = 0;
    float speed_x_fb = 100.0f; // Przykładowe wartości, możesz je zmienić
    float speed_y_fb = 100.0f;

public:
    FireballSprite(const std::string& path);
    void animate(const sf::Time &elapsed);
    void add_animation_frame(const sf::IntRect& frame);
    void MoveIt(const sf::Time &elapsed);
};

#endif // WEAPON_H
