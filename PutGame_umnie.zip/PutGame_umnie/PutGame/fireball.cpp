#include "Fireball.h"

// Implementacja klasy Fireball
Fireball::Fireball(const std::string& path) : Weapon(path)
{
    setTextureRect(sf::IntRect(0, 0, 0, 0));
}

void Fireball::animate(const sf::Time &elapsed)
{
    float dt = elapsed.asSeconds();
    t_ += dt;

    if (t_ > 0.09f) {
        fragments_index++;
        t_ = 0;
    }

    if (fragments_index >= rectVector.size()) {
        fragments_index = 0;
    }

    setTextureRect(rectVector[fragments_index]);
}

void Fireball::add_animation_frame(const sf::IntRect& frame)
{
    rectVector.push_back(frame);
}

void Fireball::MoveIt(const sf::Time &elapsed)
{
    float dt = elapsed.asSeconds();
    move(speed_x_fb * dt, speed_y_fb * dt);
}
