#ifndef GLOBAL_H
#define GLOBAL_H
#include <string>
//global
int speed_x=0;
int speed_y=0;
int speed_x_fb=0;
int speed_y_fb=0;
int zombie_amount=1;
int windowX=1000;
int windowY=1000;
int healthVar=5;
int healthEnd=0;
int Score=0;
bool intersectionOccurred = false;



//Photo link
std::string hearthPhoto= "C:/QtPrograms/PutGame/PutGame/build/heart.png";
std::string characterPhoto= "C:/QtPrograms/PutGame/PutGame/build/character.png";
std::string zombiePhoto= "C:/QtPrograms/PutGame/PutGame/build/monster.png";
std::string backgroundPhoto= "C:/QtPrograms/PutGame/PutGame/build/TILE_1G.png";
std::string fontPhoto= "C:/QtPrograms/PutGame/PutGame/build/minecraft.ttf";
std::string fireballPhoto= "C:/QtPrograms/PutGame/PutGame/build/fireball.png";
std::string axePhoto= "C:/QtPrograms/PutGame/PutGame/build/axe.png";
std::string knifePhoto= "C:/QtPrograms/PutGame/PutGame/build/knife.png";


//SCORE VALUE
int knifeScore=10;
int fireballScore=11;
int axeScore=20;
#endif // GLOBAL_H
