#ifndef CHARACTERSPRITE_H
#define CHARACTERSPRITE_H

#include <SFML/Graphics.hpp>
#include <vector>
#include <cmath>
#include <iostream>

class CharacterSprite : public sf::Sprite
{
public:
    CharacterSprite(const std::string& path, float scale_x, float scale_y, const sf::Vector2f& origin);

    void animate(const sf::Time &elapsed);
    void add_animation_frame(const sf::IntRect& frame);

protected:
    sf::Texture texture_;
    float t_ = 0.0f;
    unsigned int fragments_index = 0;
    std::vector<sf::IntRect> rectVector;
};

class MonsterSprite : public CharacterSprite
{
public:
    MonsterSprite(const std::string& path);

    void setPlayerPosition(const sf::Vector2f& position);
    void followPlayer(float deltaTime);
    void die_monster(const sf::Vector2f& playerPosition, float distance);

private:
    float speed = 50.0f + static_cast<float>(rand()) / (static_cast<float>(RAND_MAX / (100.0f - 15.0f)));
    sf::Vector2f playerPosition_;
};

class HERO : public CharacterSprite
{
public:
    HERO(const std::string& path);

    void animate_stand(const sf::Time &elapsed);
    void add_animation_frame_stand(const sf::IntRect& frame);

private:
    float t__stand = 0.0f;
    unsigned int fragments_index_stand = 0;
    std::vector<sf::IntRect> rectVector_stand;
};

class HeroSpriteWithCollision : public HERO
{
public:
    HeroSpriteWithCollision(const std::string& path);

    void setBounds(int left, int right, int top, int bottom);
    void moveInDirection(const sf::Time &elapsed, const std::vector<sf::Sprite> &obstacles);

private:
    bool Collision_T(sf::FloatRect wall_bounds, sf::FloatRect guy_bounds);
    bool Collision_L(sf::FloatRect wall_bounds, sf::FloatRect guy_bounds);
    bool Collision_B(sf::FloatRect wall_bounds, sf::FloatRect guy_bounds);
    bool Collision_R(sf::FloatRect wall_bounds, sf::FloatRect guy_bounds);

    int m_speed_x = 200;
    int m_speed_y = 200;
    int bound_top = 0;
    int bound_bottom = 0;
    int bound_left = 0;
    int bound_right = 0;
};

#endif // CHARACTERSPRITE_H
