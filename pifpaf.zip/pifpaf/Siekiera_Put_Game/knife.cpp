#include "Knife.h"

// Implementacja klasy Knife
Knife::Knife(const std::string& path) : Weapon(path)
{
    setScale(0.15f, -0.15f);
}

void Knife::MoveIt(const sf::Time &elapsed)
{
    float dt = elapsed.asSeconds();
    move(speed_x * dt, speed_y * dt);
}

void Knife::setDirection(const sf::Vector2f& direction)
{
    direction_ = direction;
    speed_x = 500 * direction_.x;
    speed_y = 500 * direction_.y;
}

void Knife::resetPosition(const sf::Vector2f& startPosition)
{
    setPosition(startPosition);
    // Ponownie ustaw kierunek na gracza
    speed_x = 500 * direction_.x;
    speed_y = 500 * direction_.y;
}
