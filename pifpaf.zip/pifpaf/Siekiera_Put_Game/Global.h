#ifndef GLOBAL_H
#define GLOBAL_H
#include <string>
//global
extern int speed_x;
extern int speed_y;
extern int speed_x_fb;
extern int speed_y_fb;
extern int zombie_amount;
extern int windowX;
extern int windowY;
extern int healthVar;
extern int healthEnd;
extern int Score;
extern bool intersectionOccurred;

int speed_x=0;
int speed_y=0;
int speed_x_fb=0;
int speed_y_fb=0;
int zombie_amount=1;
int windowX=1000;
int windowY=1000;
int healthVar=5;
int healthEnd=0;
int Score=0;
bool intersectionOccurred = false;



//Photo link
std::string hearthPhoto= "C:/Users/dawid/Desktop/PutGame_umnie/heart.png";
std::string characterPhoto= "C:/Users/dawid/Desktop/PutGame_umnie/character.png";
std::string zombiePhoto= "C:/Users/dawid/Desktop/PutGame_umnie/monster.png";
std::string backgroundPhoto= "C:/Users/dawid/Desktop/PutGame_umnie/block.png";
std::string fontPhoto= "C:/Users/dawid/Desktop/PutGame_umnie/Minecraft.ttf";
std::string fireballPhoto= "C:/Users/dawid/Desktop/PutGame_umnie/fireball.png";
std::string axePhoto= "C:/Users/dawid/Desktop/PutGame_umnie/axe.png";
std::string knifePhoto= "C:/Users/dawid/Desktop/PutGame_umnie/knife.png";


//SCORE VALUE
int knifeScore=10;
int fireballScore=11;
int axeScore=20;
#endif // GLOBAL_H
