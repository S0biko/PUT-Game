#ifndef KNIFE_H
#define KNIFE_H

#include "Weapon.h"

class Knife : public Weapon
{
public:
    Knife(const std::string& path);
    void MoveIt(const sf::Time &elapsed);
    void setDirection(const sf::Vector2f& direction);

private:
    float speed_x = 100.0f; // Przykładowe wartości, możesz je zmienić
    float speed_y = 100.0f;
    sf::Vector2f direction_;
};

#endif // KNIFE_H
