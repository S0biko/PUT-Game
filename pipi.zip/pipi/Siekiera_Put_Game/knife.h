#ifndef KNIFE_H
#define KNIFE_H

#include "Weapon.h"

class Knife : public Weapon
{
public:
    Knife(const std::string& path, const sf::Vector2f& iconPosition, sf::RenderWindow& window, const sf::Font& font);
    void animate(const sf::Time &elapsed);
    void MoveIt(const sf::Time &elapsed);
    void setDirection(const sf::Vector2f& direction);
    void update(const sf::Time &elapsed, const sf::Vector2f& playerPosition, const sf::Vector2f& direction);
    void activate(const sf::Vector2f& startPosition, const sf::Vector2f& direction);
    bool isReady() const;
    void drawIcon();

private:
    float speed_x_knife = 100.0f; // Przykładowe wartości, możesz je zmienić
    float speed_y_knife = 100.0f;
    sf::RenderWindow& window_;
    sf::Sprite icon_;
    sf::Text cooldownText_;
    sf::Clock knifeClock_;
    bool active_;
    bool ready_;
    float cooldown_;
    float duration_;

    void reset();
};

#endif // KNIFE_H
