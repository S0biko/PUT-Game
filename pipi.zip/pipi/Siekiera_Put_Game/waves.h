#ifndef WAVES_H
#define WAVES_H

#include <SFML/Graphics.hpp>
#include <vector>
#include <string>
#include "CharacterSprite.h"

void spawnWave(int waveSize, std::vector<CharacterSprite>& activeZombies, const sf::Texture& zombieTexture);
void displayCenteredText(sf::RenderWindow& window, const std::string& text, const sf::Font& font, unsigned int size, const sf::Color& color, float duration);

#endif // WAVES_H
