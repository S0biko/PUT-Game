#ifndef FIREBALL_H
#define FIREBALL_H

#include "Weapon.h"
#include <SFML/Graphics.hpp>
#include <vector>

class Fireball : public Weapon
{
public:
    Fireball(const std::string& path, const sf::Vector2f& iconPosition, sf::RenderWindow& window, const sf::Font& font);
    void animate(const sf::Time &elapsed);
    void add_animation_frame(const sf::IntRect& frame);
    void MoveIt(const sf::Time &elapsed);
    void setDirection(const sf::Vector2f& targetPosition);
    void update(const sf::Time &elapsed, const sf::Vector2f& playerPosition, const sf::Vector2f& mousePosition);
    void activate(const sf::Vector2f& startPosition, const sf::Vector2f& targetPosition);
    bool isReady() const;
    void drawIcon();

private:
    float t_ = 0.0f;
    std::vector<sf::IntRect> rectVector;
    unsigned int fragments_index = 0;
    float speed_x_fb = 100.0f; // Przykładowe wartości, możesz je zmienić
    float speed_y_fb = 100.0f;
    sf::RenderWindow& window_;
    sf::Sprite icon_;
    sf::Text cooldownText_;
    sf::Clock fireballClock_;
    bool active_;
    bool ready_;
    float cooldown_;
    float duration_;

    void reset();
};

#endif // FIREBALL_H
