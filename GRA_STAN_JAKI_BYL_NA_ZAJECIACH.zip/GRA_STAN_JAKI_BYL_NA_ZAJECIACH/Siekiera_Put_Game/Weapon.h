#ifndef WEAPON_H
#define WEAPON_H

#include <SFML/Graphics.hpp>
#include <vector>

class Weapon : public sf::Sprite
{
protected:
    sf::Texture texture_;

public:
    Weapon(const std::string& path);
    void setTexture(const sf::Texture& texture);  // Deklaracja funkcji
};

#endif // WEAPON_H
