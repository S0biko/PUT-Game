#include "Weapon.h"
#include <iostream>

// Implementacja klasy Weapon
Weapon::Weapon(const std::string& path)
{
    if (!texture_.loadFromFile(path)){
        std::cerr << "Could not load texture: " << path << std::endl;
    }
    setTexture(texture_);
    setScale(1, 1); // Ustaw skalę na domyślną wartość
}

void Weapon::setTexture(const sf::Texture& texture)
{
    texture_ = texture;
    sf::Sprite::setTexture(texture_);
}

// Implementacja klasy WeaponSprite
WeaponSprite::WeaponSprite(const std::string& path) : Weapon(path)
{
    setScale(0.15f, -0.15f);
}

void WeaponSprite::MoveIt(const sf::Time &elapsed)
{
    float dt = elapsed.asSeconds();
    move(speed_x * dt, speed_y * dt);
}

void WeaponSprite::setDirection(const sf::Vector2f& direction)
{
    direction_ = direction;
    speed_x = 500 * direction_.x;
    speed_y = 500 * direction_.y;
}

// Implementacja klasy AxeSprite
AxeSprite::AxeSprite(const std::string& path) : Weapon(path)
{
    setOrigin(400, 400); // Poprawne położenie pochodzenia
    setScale(0.2f, 0.2f);
}

// Implementacja klasy FireballSprite
FireballSprite::FireballSprite(const std::string& path) : Weapon(path)
{
    setTextureRect(sf::IntRect(0, 0, 0, 0));
}

void FireballSprite::animate(const sf::Time &elapsed)
{
    float dt = elapsed.asSeconds();
    t_ += dt;

    if (t_ > 0.09f) {
        fragments_index++;
        t_ = 0;
    }

    if (fragments_index >= rectVector.size()) {
        fragments_index = 0;
    }

    setTextureRect(rectVector[fragments_index]);
}

void FireballSprite::add_animation_frame(const sf::IntRect& frame)
{
    rectVector.push_back(frame);
}

void FireballSprite::MoveIt(const sf::Time &elapsed)
{
    float dt = elapsed.asSeconds();
    move(speed_x_fb * dt, speed_y_fb * dt);
}
