#ifndef AXE_H
#define AXE_H

#include "Weapon.h"
#include <SFML/Graphics.hpp>

class Axe : public Weapon
{
public:
    Axe(const std::string& path, const sf::Vector2f& iconPosition, sf::RenderWindow& window, const sf::Font& font);
    void rotateAround(const sf::Vector2f& center, float angle);
    void update(const sf::Time &elapsed, const sf::Vector2f& playerPosition);
    void activate();
    bool isReady() const;
    void drawIcon();

private:
    sf::RenderWindow& window_;
    sf::Sprite icon_;
    sf::Text cooldownText_;
    sf::Clock axeClock_;
    bool active_;
    bool ready_;
    float cooldown_;
    float rotationDuration_;
    float rotationSpeed_;
    float rotationAngle_;

    void reset();
};

#endif // AXE_H
