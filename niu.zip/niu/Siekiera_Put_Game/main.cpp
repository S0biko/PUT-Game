#include <iostream>
#include <vector>
#include <cmath>
#include <cstdlib>
#include <SFML/Window.hpp>
#include <SFML/Graphics.hpp>
// Funkcje globalne
#include <Global.h>
// Funkcje Postaci
#include <CharacterSprite.h>
// Funkcje broni
#include "Weapon.h"
#include "Knife.h"
#include "Fireball.h"
#include "Axe.h"
#include "displayBoundingBox.h"
// Inne funkcje
#include <livefunc.h>
#include <Health.h>
#include <string>
bool maze = false;
void runHealthExample();

void spawnWave(int waveSize, std::vector<MonsterSprite>& activeZombies, const sf::Texture& zombieTexture);
void Game_over(int wynik, bool& playAgain, bool& goToMainMenu, const std::string& fontPhoto);
void displayCenteredText(sf::RenderWindow& window, const std::string& text, const sf::Font& font, unsigned int size, const sf::Color& color, float duration);
void displayMainMenu(sf::RenderWindow& window, const sf::Font& font, bool& startGame, bool& exitGame, std::string& gameMode);

void spawnWave(int waveSize, std::vector<MonsterSprite>& activeZombies, const sf::Texture& zombieTexture) {
    for (int i = 0; i < waveSize; ++i) {
        MonsterSprite zombie(zombiePhoto);
        zombie.setTexture(zombieTexture);
        zombie.add_animation_frame(sf::IntRect(5, 70, 26, 29));
        zombie.add_animation_frame(sf::IntRect(35, 70, 26, 29));
        zombie.add_animation_frame(sf::IntRect(66, 70, 26, 29));
        zombie.add_animation_frame(sf::IntRect(100, 70, 26, 29));
        zombie.add_animation_frame(sf::IntRect(133, 70, 26, 29));
        zombie.add_animation_frame(sf::IntRect(166, 70, 26, 29));
        zombie.add_animation_frame(sf::IntRect(196, 70, 26, 29));

        float x = static_cast<float>(std::rand() % windowX);
        float y = static_cast<float>(std::rand() % windowY);
        zombie.setPosition(x, y);
        activeZombies.push_back(zombie);
    }
}

void Game_over(int wynik, bool& playAgain, bool& goToMainMenu, const std::string& fontPhoto) {
    sf::RenderWindow window_over(sf::VideoMode(500, 500), "Game over");
    sf::Font font;
    if (!font.loadFromFile(fontPhoto)) {
        std::cerr << "Could not load font: " << fontPhoto << std::endl;
        return;
    }

    sf::Text title("Game over", font, 50);
    title.setFillColor(sf::Color::White);
    title.setPosition(120, 100);

    std::string napis = "Twoj wynik to " + std::to_string(wynik);
    sf::Text wynik_napis(napis, font, 30);
    wynik_napis.setFillColor(sf::Color::White);
    wynik_napis.setPosition(120, 200);

    sf::Text playAgainText("Play Again", font, 30);
    playAgainText.setFillColor(sf::Color::White);
    playAgainText.setPosition(180, 300);

    sf::Text exitText("Main Menu", font, 30);
    exitText.setFillColor(sf::Color::White);
    exitText.setPosition(180, 350);

    while (window_over.isOpen())
    {
        sf::Event event;
        while (window_over.pollEvent(event))
        {
            if (event.type == sf::Event::Closed)
            {
                window_over.close();
            }

            if (event.type == sf::Event::MouseButtonPressed) {
                sf::Vector2i mousePos = sf::Mouse::getPosition(window_over);
                if (mousePos.x >= 180 && mousePos.x <= 320 && mousePos.y >= 300 && mousePos.y <= 330) {
                    playAgain = true;
                    window_over.close();
                }
                if (mousePos.x >= 180 && mousePos.x <= 320 && mousePos.y >= 350 && mousePos.y <= 380) {
                    goToMainMenu = true;
                    window_over.close();
                }
            }
        }

        window_over.clear();
        window_over.draw(title);
        window_over.draw(wynik_napis);
        window_over.draw(playAgainText);
        window_over.draw(exitText);
        window_over.display();
    }
}

void displayCenteredText(sf::RenderWindow& window, const std::string& text, const sf::Font& font, unsigned int size, const sf::Color& color, float duration) {
    sf::Text displayText;
    displayText.setFont(font);
    displayText.setString(text);
    displayText.setCharacterSize(size);
    displayText.setFillColor(color);

    sf::FloatRect textRect = displayText.getLocalBounds();
    displayText.setOrigin(textRect.width / 2, textRect.height / 2);
    displayText.setPosition(window.getSize().x / 2.0f, window.getSize().y / 2.0f);

    sf::Clock clock;
    while (clock.getElapsedTime().asSeconds() < duration) {
        window.clear(sf::Color::Black);
        window.draw(displayText);
        window.display();
    }
}

void displayMainMenu(sf::RenderWindow& window, const sf::Font& font, bool& startGame, bool& exitGame, std::string& gameMode) {
    sf::Text title("Main Menu", font, 50);
    title.setFillColor(sf::Color::White);
    title.setPosition(150, 100);

    sf::Text clearModeText("Clear Mode", font, 30);
    clearModeText.setFillColor(sf::Color::White);
    clearModeText.setPosition(180, 200);

    sf::Text mazeModeText("Maze Mode", font, 30);
    mazeModeText.setFillColor(sf::Color::White);
    mazeModeText.setPosition(180, 250);

    sf::Text exitText("Exit", font, 30);
    exitText.setFillColor(sf::Color::White);
    exitText.setPosition(180, 300);

    while (window.isOpen())
    {
        sf::Event event;
        while (window.pollEvent(event))
        {
            if (event.type == sf::Event::Closed)
            {
                window.close();
                exitGame = true;
            }

            if (event.type == sf::Event::MouseButtonPressed) {
                sf::Vector2i mousePos = sf::Mouse::getPosition(window);
                if (mousePos.x >= 180 && mousePos.x <= 320 && mousePos.y >= 200 && mousePos.y <= 230) {
                    startGame = true;
                    maze = false;
                    gameMode = "clear";
                    window.close();
                }
                if (mousePos.x >= 180 && mousePos.x <= 320 && mousePos.y >= 250 && mousePos.y <= 280) {
                    startGame = true;
                    maze = true;
                    gameMode = "maze";
                    window.close();
                }
                if (mousePos.x >= 180 && mousePos.x <= 320 && mousePos.y >= 300 && mousePos.y <= 330) {
                    exitGame = true;
                    window.close();
                }
            }
        }

        window.clear();
        window.draw(title);
        window.draw(clearModeText);
        window.draw(mazeModeText);
        window.draw(exitText);
        window.display();
    }
}

int main() {
    bool playAgain = false;
    bool goToMainMenu = true;
    bool exitGame = false;
    std::string gameMode;

    sf::Font font;
    if (!font.loadFromFile(fontPhoto)) {
        std::cerr << "Could not load font: " << fontPhoto << std::endl;
        return 1;
    }

    while (!exitGame)
    {
        if (goToMainMenu)
        {
            sf::RenderWindow menuWindow(sf::VideoMode(500, 500), "Main Menu");
            displayMainMenu(menuWindow, font, playAgain, exitGame, gameMode);
            goToMainMenu = false;
        }

        if (exitGame)
        {
            break;
        }

        do {
            playAgain = false;

            sf::RenderWindow window(sf::VideoMode(windowX, windowY), "PutGame");
            sf::Clock clock;

            // Initialize game state variables
            Score = 0;
            healthEnd = 0;
            healthVar = 5;
            currentWave = 1;
            zombiesPerWave = 10;
            nextWaveScoreThreshold = 3000; // Start threshold at 3000
            std::vector<MonsterSprite> activeZombies;

            // Load textures and fonts
            sf::Texture texture_wall;
            if (maze==false) {
                if (!texture_wall.loadFromFile(backgroundPhoto)) {
                    std::cerr << "Could not load texture: " << backgroundPhoto << std::endl;
                    return 1;
                }
            }
            else {
                if (!texture_wall.loadFromFile(backgroundPhotomaze)) {
                    std::cerr << "Could not load texture: " << backgroundPhoto << std::endl;
                    return 1;
                }
            }

            sf::Texture knife_texture;
            if (!knife_texture.loadFromFile(knifePhoto)) {
                std::cerr << "Could not load texture: " << knifePhoto << std::endl;
                return 1;
            }

            sf::Texture axe_texture;
            if (!axe_texture.loadFromFile(axePhoto)) {
                std::cerr << "Could not load texture: " << axePhoto << std::endl;
                return 1;
            }

            sf::Texture zombie_texture;
            if (!zombie_texture.loadFromFile(zombiePhoto)) {
                std::cerr << "Could not load texture: " << zombiePhoto << std::endl;
                return 1;
            }

            HeroSpriteWithCollision guy(characterPhoto);
            guy.add_animation_frame_stand(sf::IntRect(15, 6, 22, 30));
            guy.add_animation_frame_stand(sf::IntRect(65, 6, 22, 30));
            guy.add_animation_frame_stand(sf::IntRect(115, 6, 22, 30));
            guy.add_animation_frame(sf::IntRect(165, 6, 22, 30));
            guy.add_animation_frame(sf::IntRect(215, 6, 22, 30));
            guy.add_animation_frame(sf::IntRect(265, 6, 22, 30));
            guy.add_animation_frame(sf::IntRect(315, 6, 22, 30));
            guy.add_animation_frame(sf::IntRect(365, 6, 22, 30));
            guy.add_animation_frame(sf::IntRect(415, 6, 22, 30));
            guy.setBounds(0, window.getSize().x, 0, window.getSize().y);

            sf::Sprite grass;
            grass.setTexture(texture_wall);
            grass.setScale(1.5, 1.5);
            grass.setTextureRect(sf::IntRect(0, 0, 1500, 1500));
            std::vector<sf::Sprite> walls;

            bool IsFireb = false;

            std::vector<Knife> knives;
            for (int i = 0; i < 10; ++i) {
                Knife knife(knifePhoto, sf::Vector2f(870, 10), window, font);
                knife.setTexture(knife_texture);
                knives.push_back(knife);
            }

            Axe axe(axePhoto, sf::Vector2f(780, 10), window, font);
            axe.setTexture(axe_texture);

            Fireball fireb(fireballPhoto, sf::Vector2f(850, 10), window, font);
            fireb.add_animation_frame(sf::IntRect(40, 68, 400, 400));
            fireb.add_animation_frame(sf::IntRect(540, 68, 400, 400));
            fireb.add_animation_frame(sf::IntRect(1040, 68, 400, 400));
            fireb.add_animation_frame(sf::IntRect(1540, 68, 400, 400));
            fireb.add_animation_frame(sf::IntRect(2040, 68, 400, 400));
            fireb.add_animation_frame(sf::IntRect(2540, 68, 400, 400));

            displayCenteredText(window, "Fala 1", font, 50, sf::Color::White, 2.0f);
            spawnWave(zombiesPerWave, activeZombies, zombie_texture);

            std::vector<serce> hearts;
            serce heart1(hearthPhoto);
            serce heart2(hearthPhoto);
            serce heart3(hearthPhoto);
            serce heart4(hearthPhoto);
            serce heart5(hearthPhoto);

            heart1.setPosition(600, 10);
            heart2.setPosition(630, 10);
            heart3.setPosition(660, 10);
            heart4.setPosition(690, 10);
            heart5.setPosition(720, 10);

            hearts.push_back(heart1);
            hearts.push_back(heart2);
            hearts.push_back(heart3);
            hearts.push_back(heart4);
            hearts.push_back(heart5);

            sf::Text scoreText;
            scoreText.setFont(font);
            scoreText.setCharacterSize(30);
            scoreText.setFillColor(sf::Color::White);
            scoreText.setPosition(340, 10);

            sf::Text exitText;
            exitText.setFont(font);
            exitText.setCharacterSize(15);
            exitText.setFillColor(sf::Color::White);
            exitText.setPosition(20, 10);
            std::string exitString = "Press Esc to SHUTDOWN";

            while (window.isOpen())
            {
                sf::Time elapsed = clock.restart();

                float dt = elapsed.asSeconds();
                static float counter_fireb = 0;
                static float counter_knife = 0;
                static float counter = 0;
                static float counter_lives = 0;
                static float counter_fireb_max = 0;

                counter += dt;
                counter_fireb += dt;
                counter_knife += dt;
                counter_lives += dt;
                counter_fireb_max += dt;

                if (Score >= nextWaveScoreThreshold) {
                    currentWave++;
                    zombiesPerWave += 5;
                    nextWaveScoreThreshold += 3000; // Increment by 3000 for next wave
                    displayCenteredText(window, "Fala " + std::to_string(currentWave), font, 50, sf::Color::White, 2.0f);
                    spawnWave(zombiesPerWave, activeZombies, zombie_texture); // Rozpoczęcie nowej fali
                }

                if (sf::Keyboard::isKeyPressed(sf::Keyboard::R) && fireb.isReady()) {
                    sf::Vector2i mousePos = sf::Mouse::getPosition(window);
                    fireb.activate(guy.getPosition(), window.mapPixelToCoords(mousePos));
                }

                fireb.update(elapsed, guy.getPosition(), window.mapPixelToCoords(sf::Mouse::getPosition(window)));

                sf::Event event;
                while (window.pollEvent(event))
                {
                    if (event.type == sf::Event::Closed)
                    {
                        std::cout << "Closing Window" << std::endl;
                        Game_over(Score, playAgain, goToMainMenu, fontPhoto);
                        window.close();
                    }
                    if (event.type == sf::Event::KeyPressed && event.key.code == sf::Keyboard::Escape)
                    {
                        std::cout << "Closing Window" << std::endl;
                        Game_over(Score, playAgain, goToMainMenu, fontPhoto);
                        window.close();
                    }
                    if (event.type == sf::Event::KeyPressed && event.key.code == sf::Keyboard::E)
                    {
                        axe.activate();
                    }
                }

                sf::FloatRect guy_bounds = guy.getGlobalBounds();
                bool currentIntersection = false;

                sf::Vector2f position;
                sf::FloatRect fireball_bounds = fireb.getGlobalBounds();

                guy.setBounds(0, window.getSize().x, 0, window.getSize().y);
                guy.moveInDirection(elapsed, walls);

                // Automatyczne rzucanie noży w kierunku poruszania się postaci
                if (knives[0].isReady()) {
                    for (auto& knife : knives) {
                        knife.activate(guy.getPosition(), guy.getDirection());
                    }
                }

                window.clear(sf::Color::Black);
                window.draw(grass);
                window.draw(guy);
                for (auto &heart : hearts)
                {
                    window.draw(heart);
                }

                for (auto& knife : knives)
                {
                    knife.MoveIt(elapsed);
                    window.draw(knife);
                    displayBoundingBox(knife, window);
                }

                fireb.MoveIt(elapsed);
                fireb.animate(elapsed);

                axe.update(elapsed, guy.getPosition());

                displayBoundingBox(guy, window);
                displayBoundingBox(fireb, window);
                displayBoundingBox(axe, window);

                for (auto& sprite : activeZombies)
                {
                    sf::FloatRect monster_bounds = sprite.getGlobalBounds();
                    if (monster_bounds.intersects(guy_bounds) && counter_lives > 1.0)
                    {
                        currentIntersection = true;
                        counter_lives = 0;
                    }

                    if (currentIntersection && !intersectionOccurred)
                    {
                        intersectionOccurred = true;

                        if (healthEnd < healthVar)
                        {
                            hearts[healthEnd].setScale(0, 0);
                            healthEnd++;
                        }

                        if (healthEnd == healthVar)
                        {
                            std::cout << "Twoj wynik to: " << Score << " ";
                            Game_over(Score, playAgain, goToMainMenu, fontPhoto);
                            window.close();
                        }
                    }
                    else if (!currentIntersection)
                    {
                        intersectionOccurred = false;
                    }

                    for (auto& knife : knives)
                    {
                        sf::FloatRect knife_bounds = knife.getGlobalBounds();
                        if (monster_bounds.intersects(knife_bounds))
                        {
                            Score += knifeScore;
                            sprite.die_monster(guy.getPosition(), 400);
                            knife.setPosition(-100, -100);
                        }
                    }

                    if (monster_bounds.intersects(fireball_bounds))
                    {
                        Score += fireballScore;
                        sprite.die_monster(guy.getPosition(), 400);
                    }

                    if (monster_bounds.intersects(axe.getGlobalBounds()))
                    {
                        Score += axeScore;
                        sprite.die_monster(guy.getPosition(), 400);
                    }

                    sprite.setPlayerPosition(guy.getPosition());
                    sprite.followPlayer(dt);
                    sprite.animate(elapsed);
                    displayBoundingBox(sprite, window);
                    window.draw(sprite);
                }

                std::string scoreString = "Wynik: " + std::to_string(Score);
                scoreText.setString(scoreString);
                window.draw(scoreText);

                exitText.setString(exitString);
                window.draw(exitText);

                fireb.drawIcon();
                for (auto& knife : knives) {
                    knife.drawIcon();
                }

                window.display();
            }

        } while (playAgain);

        goToMainMenu = true;
    }

    return 0;
}
