#ifndef KNIFE_H
#define KNIFE_H

#include "Weapon.h"

class Knife : public Weapon
{
public:
    Knife(const std::string& path, const sf::Vector2f& iconPosition, sf::RenderWindow& window, const sf::Font& font);
    void animate(const sf::Time &elapsed);
    void add_animation_frame(const sf::IntRect& frame);
    void MoveIt(const sf::Time &elapsed);
    void setDirection(const sf::Vector2f& targetPosition);
    void update(const sf::Time &elapsed, const sf::Vector2f& playerPosition, const sf::Vector2f& direction);
    void activate(const sf::Vector2f& startPosition, const sf::Vector2f& targetPosition);
    bool isReady() const;
    void drawIcon();

private:
    float t_ = 0.0f;
    std::vector<sf::IntRect> rectVector;
    unsigned int fragments_index = 0;
    float speed_x = 100.0f; // Przykładowe wartości, możesz je zmienić
    float speed_y = 100.0f;
    sf::RenderWindow& window_;
    sf::Sprite icon_;
    sf::Text cooldownText_;
    sf::Clock knifeClock_;
    bool active_;
    bool ready_;
    float cooldown_;
    float duration_;

    void reset();
};

#endif // KNIFE_H
