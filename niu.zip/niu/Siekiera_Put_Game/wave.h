#ifndef WAVE_H
#define WAVE_H

#include <SFML/Graphics.hpp>
#include <vector>
#include "MonsterSprite.h"

void spawnWave(int waveSize, std::vector<MonsterSprite>& activeZombies, const sf::Texture& zombieTexture);
void displayCenteredText(sf::RenderWindow& window, const std::string& text, const sf::Font& font, unsigned int size, const sf::Color& color, float duration);

#endif // WAVE_H
