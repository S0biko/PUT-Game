#include "Fireball.h"
#include <cmath>
#include <iostream>

// Implementacja klasy Fireball
Fireball::Fireball(const std::string& path, const sf::Vector2f& iconPosition, sf::RenderWindow& window, const sf::Font& font)
    : Weapon(path), window_(window), active_(false), ready_(true), cooldown_(10.0f), duration_(5.0f)
{
    if (!texture_.loadFromFile(path)) {
        std::cerr << "Could not load texture: " << path << std::endl;
    } else {
        setTexture(texture_);
    }

    setScale(0.3f, 0.3f); // Zwiększenie wielkości fireballa

    icon_.setTexture(texture_);
    icon_.setTextureRect(sf::IntRect(40, 68, 400, 400)); // First frame of fireball animation
    icon_.setScale(0.1f, 0.1f); // Adjust the scale if needed
    icon_.setPosition(iconPosition);

    cooldownText_.setFont(font);
    cooldownText_.setCharacterSize(15);
    cooldownText_.setFillColor(sf::Color::Red);
    cooldownText_.setPosition(iconPosition.x, iconPosition.y + 40); // Pozycjonowanie tekstu pod ikoną
}

void Fireball::animate(const sf::Time &elapsed)
{
    float dt = elapsed.asSeconds();
    t_ += dt;

    if (t_ > 0.09f) {
        fragments_index++;
        t_ = 0;
    }

    if (fragments_index >= rectVector.size()) {
        fragments_index = 0;
    }

    setTextureRect(rectVector[fragments_index]);
}

void Fireball::add_animation_frame(const sf::IntRect& frame)
{
    rectVector.push_back(frame);
}

void Fireball::MoveIt(const sf::Time &elapsed)
{
    float dt = elapsed.asSeconds();
    move(speed_x_fb * dt, speed_y_fb * dt);
}

void Fireball::setDirection(const sf::Vector2f& targetPosition)
{
    sf::Vector2f direction = targetPosition - getPosition();
    float length = std::sqrt(direction.x * direction.x + direction.y * direction.y);
    direction /= length;
    speed_x_fb = direction.x * 250;
    speed_y_fb = direction.y * 250;
    float rotation = std::atan2(direction.y, direction.x) * 180.f / static_cast<float>(M_PI);
    setRotation(rotation);
}

void Fireball::update(const sf::Time &elapsed, const sf::Vector2f& playerPosition, const sf::Vector2f& mousePosition)
{
    sf::Time fireballElapsed = fireballClock_.getElapsedTime();

    if (active_) {
        MoveIt(elapsed);
        animate(elapsed);
        window_.draw(*this);
        if (fireballElapsed.asSeconds() >= duration_) {
            active_ = false;
            reset();
        }
    }

    if (fireballElapsed.asSeconds() >= cooldown_) {
        ready_ = true;
    }

    if (!ready_) {
        float cooldownTimeLeft = cooldown_ - fireballElapsed.asSeconds();
        cooldownText_.setString(std::to_string(cooldownTimeLeft).substr(0, 4));
        icon_.setColor(sf::Color(255, 255, 255, 128));
    } else {
        cooldownText_.setString("");
        icon_.setColor(sf::Color(255, 255, 255, 255));
    }

    drawIcon();
}

void Fireball::activate(const sf::Vector2f& startPosition, const sf::Vector2f& targetPosition)
{
    if (ready_) {
        active_ = true;
        ready_ = false;
        fireballClock_.restart();
        setPosition(startPosition); // Ustaw pozycję początkową fireballa na pozycję gracza
        setDirection(targetPosition); // Ustaw kierunek w stronę kursora
    }
}

bool Fireball::isReady() const
{
    return ready_;
}

bool Fireball::isActive() const
{
    return active_;
}

void Fireball::drawIcon()
{
    window_.draw(icon_);
    window_.draw(cooldownText_);
}

void Fireball::reset()
{
    setPosition(-100, -100);
    active_ = false;
}
