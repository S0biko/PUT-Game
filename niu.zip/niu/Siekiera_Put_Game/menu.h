#ifndef MENU_H
#define MENU_H

#include <SFML/Graphics.hpp>
#include <string>

void displayMainMenu(sf::RenderWindow& window, const sf::Font& font, bool& startGame, bool& exitGame, std::string& gameMode);
void Game_over(int wynik, bool& playAgain, bool& goToMainMenu, const std::string& fontPhoto);

#endif // MENU_H
