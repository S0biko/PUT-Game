#ifndef DISPLAYBOUNDINGBOX_H
#define DISPLAYBOUNDINGBOX_H

#include <SFML/Graphics.hpp>

void displayBoundingBox(const sf::Sprite& sprite, sf::RenderWindow& window);

#endif // DISPLAYBOUNDINGBOX_H
