#include "Axe.h"
#include <iostream>
#include <cmath>

Axe::Axe(const std::string& path, const sf::Vector2f& iconPosition, sf::RenderWindow& window, const sf::Font& font)
    : Weapon(path), window_(window), active_(false), ready_(true), cooldown_(10.0f), rotationDuration_(1.0f), rotationSpeed_(0.0f), rotationAngle_(0.0f)
{
    setOrigin(texture_.getSize().x / 2, texture_.getSize().y / 2);
    setScale(0.2f, 0.2f);

    if (!texture_.loadFromFile(path)) {
        std::cerr << "Could not load texture: " << path << std::endl;
    } else {
        setTexture(texture_);
    }

    icon_.setTexture(texture_);
    icon_.setScale(0.12f, 0.12f);
    icon_.setPosition(iconPosition);

    cooldownText_.setFont(font);
    cooldownText_.setCharacterSize(15);
    cooldownText_.setFillColor(sf::Color::Black); // Zmiana koloru tekstu na czarny
    cooldownText_.setPosition(iconPosition.x, iconPosition.y + 40); // Pozycjonowanie tekstu pod ikoną
}

void Axe::rotateAround(const sf::Vector2f& center, float angle)
{
    rotationAngle_ += angle;
    setPosition(center.x + std::cos(rotationAngle_) * 50, center.y + std::sin(rotationAngle_) * 50);
    setRotation(rotationAngle_ * 180 / 3.14159265f);
}

void Axe::update(const sf::Time &elapsed, const sf::Vector2f& playerPosition)
{
    sf::Time axeElapsed = axeClock_.getElapsedTime();

    if (active_) {
        float rotationStep = 2 * 3.14159265f / (rotationDuration_ / elapsed.asSeconds());
        rotateAround(playerPosition, rotationStep);
        window_.draw(*this);
        if (axeElapsed.asSeconds() >= rotationDuration_) {
            active_ = false;
            reset();
        }
    }

    if (axeElapsed.asSeconds() >= cooldown_) {
        ready_ = true;
    }

    if (!ready_) {
        float cooldownTimeLeft = cooldown_ - axeElapsed.asSeconds();
        cooldownText_.setString("Cooldown: " + std::to_string(cooldownTimeLeft).substr(0, 4));
        icon_.setColor(sf::Color(255, 255, 255, 128));
    } else {
        cooldownText_.setString("");
        icon_.setColor(sf::Color(255, 255, 255, 255));
    }

    drawIcon();
}

void Axe::activate()
{
    if (ready_) {
        active_ = true;
        ready_ = false;
        axeClock_.restart();
    }
}

bool Axe::isReady() const
{
    return ready_;
}

void Axe::drawIcon()
{
    window_.draw(icon_);
    window_.draw(cooldownText_);
}

void Axe::reset()
{
    setPosition(-100, -100);
}
