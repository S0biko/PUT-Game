#ifndef WEAPONSPRITE_H
#define WEAPONSPRITE_H

#include "Weapon.h"

class WeaponSprite : public Weapon {
private:
    sf::Clock throwClock;
    float throwCooldown;

public:
    WeaponSprite(const std::string& path);
    bool canThrowKnife() const;
    void resetThrowCooldown();
    float getCooldownRemaining() const;
};

#endif // WEAPONSPRITE_H
