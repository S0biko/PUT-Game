#include "settings.h"

Settings::Settings() {
    // Domyślne przypisania klawiszy
    keyBindings["MoveUp"] = sf::Keyboard::W;
    keyBindings["MoveDown"] = sf::Keyboard::S;
    keyBindings["MoveLeft"] = sf::Keyboard::A;
    keyBindings["MoveRight"] = sf::Keyboard::D;
}

void Settings::setKey(const std::string& action, sf::Keyboard::Key key) {
    keyBindings[action] = key;
}

sf::Keyboard::Key Settings::getKey(const std::string& action) const {
    auto it = keyBindings.find(action);
    if (it != keyBindings.end()) {
        return it->second;
    }
    return sf::Keyboard::Unknown;
}
