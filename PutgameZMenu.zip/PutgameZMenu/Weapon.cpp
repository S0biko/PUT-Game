#include "Weapon.h"
#include <iostream>

Weapon::Weapon(const std::string& path) : active(false), speed_x(0.0f), speed_y(0.0f) {
    if (!texture.loadFromFile(path)) {
        std::cerr << "Failed to load texture: " << path << std::endl;
    }
    setTexture(texture);
}

void Weapon::setSpeed(float speedX, float speedY) {
    speed_x = speedX;
    speed_y = speedY;
}

void Weapon::moveIt(const sf::Time &elapsed) {
    float dt = elapsed.asSeconds();
    move(speed_x * dt, speed_y * dt);
}

bool Weapon::isActive() const {
    return active;
}

void Weapon::activate() {
    active = true;
}

void Weapon::deactivate() {
    active = false;
}

void Weapon::update(const sf::Time& elapsed) {
    // Aktualizacja stanu broni (ruch itp.)
    moveIt(elapsed);
}
