#ifndef livefunc_H
#define livefunc_H

#include <SFML/Graphics.hpp>
#include <string>

class serce : public sf::Sprite
{
public:
    serce(const std::string& path);

private:
    sf::Texture texture_;
};

#endif // livefunc_H
