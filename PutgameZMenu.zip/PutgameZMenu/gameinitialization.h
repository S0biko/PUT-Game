#ifndef GAMEINITIALIZATION_H
#define GAMEINITIALIZATION_H

#include <SFML/Graphics.hpp>
#include "CharacterSprite.h"
#include "Weapon.h"
#include "livefunc.h"
#include "monstersprite.h"
void initializeGame(sf::RenderWindow& window, sf::Font& font, HeroSpriteWithCollision& guy, std::vector<sf::Sprite>& walls, std::vector<serce>& hearts, std::vector<MonsterSprite>& sprites, sf::Sprite& grass);

#endif
