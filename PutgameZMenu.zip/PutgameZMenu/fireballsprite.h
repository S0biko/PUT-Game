#ifndef FIREBALLSPRITE_H
#define FIREBALLSPRITE_H

#include "Weapon.h"
#include <vector>

class FireballSprite : public Weapon {
private:
    float t_;
    std::vector<sf::IntRect> rectVector;
    unsigned int fragments_index;

public:
    FireballSprite(const std::string& path);
    void animate(const sf::Time &elapsed);
    void addAnimationFrame(const sf::IntRect& frame);
    void activate(const sf::Vector2f& position, float angle, float speed);
    void update(const sf::Time& elapsed) override; // Dodajemy metodę update
};

#endif // FIREBALLSPRITE_H
