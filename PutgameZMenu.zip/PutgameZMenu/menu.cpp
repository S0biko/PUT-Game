#include "menu.h"
#include "settings.h"

// Funkcja odpowiedzialna za wyświetlanie menu z obrazem w tle
void displayMenu(sf::RenderWindow& window, sf::Font& font, const sf::Texture& backgroundTexture) {
    // Czyszczenie okna (bez ustawiania koloru tła, ponieważ mamy obraz w tle)
    window.clear();

    // Ustawienie obrazu tła
    sf::Sprite background(backgroundTexture);
    window.draw(background);

    // Ustawienie i wyświetlenie tytułu gry
    sf::Text title("PutGame", font, 50);
    title.setFillColor(sf::Color::White);
    title.setPosition(300, 100);
    window.draw(title);

    // Ustawienie i wyświetlenie opcji "Play"
    sf::Text play("Play", font, 30);
    play.setFillColor(sf::Color::White);
    play.setPosition(350, 250);
    window.draw(play);

    // Ustawienie i wyświetlenie opcji "Settings"
    sf::Text settings("Settings", font, 30);
    settings.setFillColor(sf::Color::White);
    settings.setPosition(350, 300);
    window.draw(settings);

    // Ustawienie i wyświetlenie opcji "Exit"
    sf::Text exit("Exit", font, 30);
    exit.setFillColor(sf::Color::White);
    exit.setPosition(350, 350);
    window.draw(exit);

    // Wyświetlenie wszystkiego na ekranie
    window.display();
}

// Funkcja obsługująca zdarzenia w menu, zwracająca true jeśli wybrano "Play" i false w pozostałych przypadkach
bool handleMenuEvents(sf::RenderWindow& window, sf::Font& font, Settings& settings) {
    sf::Event event;
    // Pętla obsługująca zdarzenia
    while (window.pollEvent(event)) {
        // Zdarzenie zamknięcia okna
        if (event.type == sf::Event::Closed) {
            window.close();
            return false;
        }
        // Zdarzenie naciśnięcia klawisza Escape
        if (event.type == sf::Event::KeyPressed && event.key.code == sf::Keyboard::Escape) {
            window.close();
            return false;
        }
        // Zdarzenie kliknięcia myszką
        if (event.type == sf::Event::MouseButtonPressed) {
            sf::Vector2i mousePos = sf::Mouse::getPosition(window);
            // Sprawdzenie czy kliknięto na opcję "Play"
            if (mousePos.x >= 350 && mousePos.x <= 450) {
                if (mousePos.y >= 250 && mousePos.y <= 280) {
                    return true; // Gra rozpoczyna się
                }
                // Sprawdzenie czy kliknięto na opcję "Settings"
                if (mousePos.y >= 300 && mousePos.y <= 330) {
                    displaySettings(window, font, settings);
                }
                // Sprawdzenie czy kliknięto na opcję "Exit"
                if (mousePos.y >= 350 && mousePos.y <= 380) {
                    window.close();
                    return false; // Wyjście z gry
                }
            }
        }
    }
    return false; // Domyślny zwrot false, jeśli żadne zdarzenie nie zostało obsłużone
}

// Funkcja odpowiedzialna za wyświetlanie ekranu ustawień
void displaySettings(sf::RenderWindow& window, sf::Font& font, Settings& settings) {
    while (window.isOpen()) {
        window.clear(sf::Color::Black);

        // Ustawienie i wyświetlenie tytułu "Settings"
        sf::Text title("Settings", font, 50);
        title.setFillColor(sf::Color::White);
        title.setPosition(300, 100);
        window.draw(title);

        // Wyświetlenie opcji zmiany klawiszy
        sf::Text up("Move Up: Press new key", font, 30);
        up.setFillColor(sf::Color::White);
        up.setPosition(350, 200);
        window.draw(up);

        sf::Text down("Move Down: Press new key", font, 30);
        down.setFillColor(sf::Color::White);
        down.setPosition(350, 250);
        window.draw(down);

        sf::Text left("Move Left: Press new key", font, 30);
        left.setFillColor(sf::Color::White);
        left.setPosition(350, 300);
        window.draw(left);

        sf::Text right("Move Right: Press new key", font, 30);
        right.setFillColor(sf::Color::White);
        right.setPosition(350, 350);
        window.draw(right);

        // Wyświetlenie opcji powrotu do menu
        sf::Text back("Back to Menu", font, 30);
        back.setFillColor(sf::Color::White);
        back.setPosition(350, 400);
        window.draw(back);

        // Wyświetlenie wszystkiego na ekranie
        window.display();

        // Obsługa zdarzeń dla ekranu ustawień
        sf::Event event;
        while (window.pollEvent(event)) {
            if (event.type == sf::Event::Closed) {
                window.close();
                return;
            }
            if (event.type == sf::Event::KeyPressed) {
                if (event.key.code == sf::Keyboard::Escape) {
                    return;
                }

                sf::Vector2i mousePos = sf::Mouse::getPosition(window);

                // Sprawdzenie, który klawisz został naciśnięty, i zaktualizowanie ustawień
                if (mousePos.y >= 200 && mousePos.y <= 230) {
                    settings.setKey("MoveUp", event.key.code);
                } else if (mousePos.y >= 250 && mousePos.y <= 280) {
                    settings.setKey("MoveDown", event.key.code);
                } else if (mousePos.y >= 300 && mousePos.y <= 330) {
                    settings.setKey("MoveLeft", event.key.code);
                } else if (mousePos.y >= 350 && mousePos.y <= 380) {
                    settings.setKey("MoveRight", event.key.code);
                }
            }

            if (event.type == sf::Event::MouseButtonPressed) {
                sf::Vector2i mousePos = sf::Mouse::getPosition(window);
                if (mousePos.x >= 350 && mousePos.x <= 550) {
                    if (mousePos.y >= 400 && mousePos.y <= 430) {
                        return; // Powrót do menu
                    }
                }
            }
        }
    }
}
