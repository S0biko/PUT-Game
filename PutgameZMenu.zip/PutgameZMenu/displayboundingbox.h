#ifndef DISPLAY_BOUNDING_BOX_H
#define DISPLAY_BOUNDING_BOX_H

#include <SFML/Graphics.hpp>

void displayBoundingBox(const sf::Sprite& sprite, sf::RenderWindow& window);

#endif
