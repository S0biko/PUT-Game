#include "menu.h"
#include <SFML/Window.hpp>
#include <SFML/Graphics.hpp>
// Funkcje globalne
#include <Global.h>
// Funkcje Postaci
#include <CharacterSprite.h>
// Funkcje broni
#include <Weapon.h>
// Inne funkcje
#include <livefunc.h>
#include "Game.h"
#include "settings.h"

std::string fontPhoto = "C:/QtPrograms/PutGame/PutGame/build/minecraft.ttf";
std::string backgroundMenuPhoto= "C:/QtPrograms/PutGame/PutGame/build/heart.png";

int main() {
    sf::RenderWindow window(sf::VideoMode(1000, 1000), "PutGame");
    sf::Font font;
    if (!font.loadFromFile(fontPhoto)) {
        return 1;
    }

    sf::Texture backgroundTexture;
    if (!backgroundTexture.loadFromFile(backgroundMenuPhoto)) {
        return 1;
    }

    Settings settings;
    bool inMenu = true;
    while (window.isOpen()) {
        if (inMenu) {
            displayMenu(window, font, backgroundTexture);
            inMenu = !handleMenuEvents(window, font, settings);
        } else {
            runGame(window, font, settings);
            inMenu = true;  // After the game ends, go back to menu
        }
    }

    return 0;
}
