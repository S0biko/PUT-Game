#include "CharacterSprite.h"
#include "settings.h"
#include <iostream>

HeroSpriteWithCollision::HeroSpriteWithCollision(const std::string& path) {
    if (!texture.loadFromFile(path)) {
        std::cerr << "Failed to load texture: " << path << std::endl;
    }
    setTexture(texture);
    speed_x = 0.0f;
    speed_y = 0.0f;
}

void HeroSpriteWithCollision::add_animation_frame_stand(const sf::IntRect& frame) {
    animationFramesStand.push_back(frame);
}

void HeroSpriteWithCollision::add_animation_frame(const sf::IntRect& frame) {
    animationFramesRun.push_back(frame);
}

void HeroSpriteWithCollision::moveInDirection(const sf::Time& elapsed, const std::vector<sf::Sprite>& walls, const Settings& settings) {
    float dt = elapsed.asSeconds();
    // Implementacja ruchu postaci
    // ...
}

void HeroSpriteWithCollision::setBounds(int left, int right, int top, int bottom) {
    // Implementacja ograniczeń ruchu
}

void HeroSpriteWithCollision::update(const sf::Time& elapsed) {
    // Aktualizacja stanu postaci (animacje, pozycja itp.)
    // ...
}
