#include "MonsterSprite.h"
#include <iostream>
#include <cmath>

MonsterSprite::MonsterSprite(const std::string& path) {
    if (!texture.loadFromFile(path)) {
        std::cerr << "Failed to load texture: " << path << std::endl;
    }
    setTexture(texture);
    speed_x = 0.0f;
    speed_y = 0.0f;
}

void MonsterSprite::add_animation_frame(const sf::IntRect& frame) {
    animationFrames.push_back(frame);
}

void MonsterSprite::followPlayer(const sf::Time& elapsed, const sf::Vector2f& playerPosition) {
    // Implementacja podążania za graczem
    // ...
}

void MonsterSprite::die_monster(const sf::Vector2f& playerPosition, float range) {
    // Implementacja śmierci potwora
    // ...
}

void MonsterSprite::update(const sf::Time& elapsed, const sf::Vector2f& playerPosition) {
    // Aktualizacja stanu potwora (ruch, animacje itp.)
    followPlayer(elapsed, playerPosition);
}
