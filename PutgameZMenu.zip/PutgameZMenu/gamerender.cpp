#include "GameRender.h"

void renderGame(sf::RenderWindow& window, HeroSpriteWithCollision& guy, WeaponSprite& knife, AxeSprite& axe, FireballSprite& fireb, std::vector<sf::Sprite>& walls, std::vector<MonsterSprite>& sprites, std::vector<serce>& hearts, sf::Text& scoreText, sf::Text& ExitText, sf::Sprite& knifeIcon, sf::Text& knifeCooldownText) {
    window.clear(sf::Color::Black);

    // Rysowanie tła i obiektów
    for (auto& wall : walls) {
        window.draw(wall);
    }
    window.draw(guy);

    for (auto& heart : hearts) {
        window.draw(heart);
    }

    if (knife.isActive()) {
        window.draw(knife);
    }

    if (axe.isActive()) {
        window.draw(axe);
    }

    if (fireb.isActive()) {
        window.draw(fireb);
    }

    for (auto& sprite : sprites) {
        window.draw(sprite);
    }

    window.draw(scoreText);
    window.draw(ExitText);
    window.draw(knifeIcon);
    window.draw(knifeCooldownText);

    window.display();
}
