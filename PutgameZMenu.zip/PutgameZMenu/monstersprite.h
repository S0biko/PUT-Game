#ifndef MONSTERSPRITE_H
#define MONSTERSPRITE_H

#include <SFML/Graphics.hpp>
#include <vector>

class MonsterSprite : public sf::Sprite {
private:
    sf::Texture texture;
    std::vector<sf::IntRect> animationFrames;
    float speed_x, speed_y;

public:
    MonsterSprite(const std::string& path);
    void add_animation_frame(const sf::IntRect& frame);
    void followPlayer(const sf::Time& elapsed, const sf::Vector2f& playerPosition);
    void die_monster(const sf::Vector2f& playerPosition, float range);
    void update(const sf::Time& elapsed, const sf::Vector2f& playerPosition); // Dodajemy metodę update
};

#endif // MONSTERSPRITE_H
