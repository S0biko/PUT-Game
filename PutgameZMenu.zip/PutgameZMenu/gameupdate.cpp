#include "GameUpdate.h"
#include "Global.h"
#include "livefunc.h"
#include "math.h""
void updateGame(sf::RenderWindow& window, sf::Time elapsed, HeroSpriteWithCollision& guy, WeaponSprite& knife, AxeSprite& axe, FireballSprite& fireb, std::vector<sf::Sprite>& walls, std::vector<MonsterSprite>& sprites, std::vector<serce>& hearts, int& Score, sf::Font& font, const Settings& settings) {
    float dt = elapsed.asSeconds();
    static float counter_fireb = 0;
    static float counter_knife = 0;
    static float counter = 0;
    static float counter_lives = 0;

    counter += dt;
    counter_fireb += dt;
    counter_knife += dt;
    counter_lives += dt;

    if (counter > 1.0f) {
        MonsterSprite zombie(zombiePhoto);
        zombie.add_animation_frame(sf::IntRect(5, 70, 26, 29));
        zombie.add_animation_frame(sf::IntRect(35, 70, 26, 29));
        zombie.add_animation_frame(sf::IntRect(66, 70, 26, 29));
        zombie.add_animation_frame(sf::IntRect(100, 70, 26, 29));
        zombie.add_animation_frame(sf::IntRect(133, 70, 26, 29));
        zombie.add_animation_frame(sf::IntRect(166, 70, 26, 29));
        zombie.add_animation_frame(sf::IntRect(196, 70, 26, 29));
        sprites.push_back(zombie);
        zombie.die_monster(guy.getPosition(), 600);
        counter = 0;
    }

    if (counter_fireb > 3.0f && !fireb.isActive()) {
        fireb.setScale(0.2f, 0.2f);
        float angle = static_cast<float>(std::rand()) / static_cast<float>(RAND_MAX) * 2 * M_PI;
        fireb.activate(guy.getPosition(), angle, 250);
        counter_fireb = 0;
    }

    if (sf::Keyboard::isKeyPressed(settings.getKey("MoveLeft"))) {
        guy.moveInDirection(elapsed, walls, settings);
    }

    if (sf::Keyboard::isKeyPressed(settings.getKey("MoveRight"))) {
        guy.moveInDirection(elapsed, walls, settings);
    }

    if (sf::Keyboard::isKeyPressed(settings.getKey("MoveUp"))) {
        guy.moveInDirection(elapsed, walls, settings);
    }

    if (sf::Keyboard::isKeyPressed(settings.getKey("MoveDown"))) {
        guy.moveInDirection(elapsed, walls, settings);
    }

    if (sf::Keyboard::isKeyPressed(sf::Keyboard::Q) && knife.canThrowKnife()) {
        float angle = static_cast<float>(std::rand()) / static_cast<float>(RAND_MAX) * 2 * M_PI;
        knife.setPosition(guy.getPosition());
        knife.setSpeed(500 * cos(angle), 500 * sin(angle));
        knife.setRotation(angle);
        knife.activate();
        knife.resetThrowCooldown();
    }

    // Aktualizacja położenia i animacji
    guy.update(elapsed);
    knife.update(elapsed);
    fireb.update(elapsed);

    for (auto& sprite : sprites) {
        sprite.update(elapsed, guy.getPosition());
    }
}
