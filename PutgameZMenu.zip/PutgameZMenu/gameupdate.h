#ifndef GAMEUPDATE_H
#define GAMEUPDATE_H
#include "monstersprite.h"
#include "livefunc.h"
#include <SFML/Graphics.hpp>
#include "CharacterSprite.h"
#include "Weapon.h"
#include "settings.h"
#include "weaponsprite.h"
#include "axesprite.h"
#include "fireballsprite.h"
void updateGame(sf::RenderWindow& window, sf::Time elapsed, HeroSpriteWithCollision& guy, WeaponSprite& knife, AxeSprite& axe, FireballSprite& fireb, std::vector<sf::Sprite>& walls, std::vector<MonsterSprite>& sprites, std::vector<serce>& hearts, int& Score, sf::Font& font, const Settings& settings);

#endif
