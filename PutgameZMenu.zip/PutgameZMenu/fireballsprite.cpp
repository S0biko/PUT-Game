#include "FireballSprite.h"
#include "math.h"
FireballSprite::FireballSprite(const std::string& path) : Weapon(path), t_(0.0f), fragments_index(0) {
    setTextureRect(sf::IntRect(0, 0, 0, 0));
}

void FireballSprite::animate(const sf::Time &elapsed) {
    float dt = elapsed.asSeconds();
    t_ += dt;

    if (t_ > 0.09f) {
        fragments_index++;
        t_ = 0;
    }

    if (fragments_index >= rectVector.size()) {
        fragments_index = 0;
    }

    setTextureRect(rectVector[fragments_index]);
}

void FireballSprite::addAnimationFrame(const sf::IntRect& frame) {
    rectVector.push_back(frame);
}

void FireballSprite::activate(const sf::Vector2f& position, float angle, float speed) {
    setPosition(position);
    setSpeed(speed * cos(angle), speed * sin(angle));
    float rotation = std::atan2(sin(angle), cos(angle)) * 180.f / static_cast<float>(M_PI);
    setRotation(rotation);
    Weapon::activate();
}

void FireballSprite::update(const sf::Time& elapsed) {
    // Aktualizacja stanu fireballa (ruch, animacje itp.)
    moveIt(elapsed);
    animate(elapsed);
}
