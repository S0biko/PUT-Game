#ifndef SETTINGS_H
#define SETTINGS_H

#include <SFML/Window.hpp>
#include <map>
#include <string>

// Klasa przechowująca ustawienia klawiszy
class Settings {
public:
    Settings();

    // Funkcje do zmiany i pobierania ustawień klawiszy
    void setKey(const std::string& action, sf::Keyboard::Key key);
    sf::Keyboard::Key getKey(const std::string& action) const;

private:
    std::map<std::string, sf::Keyboard::Key> keyBindings;
};

#endif
