#ifndef MENU_H
#define MENU_H

#include <SFML/Graphics.hpp>
#include "settings.h"

// Funkcja odpowiedzialna za wyświetlanie menu z obrazem w tle
void displayMenu(sf::RenderWindow& window, sf::Font& font, const sf::Texture& backgroundTexture);

// Funkcja obsługująca zdarzenia w menu, zwracająca true jeśli wybrano "Play" i false w pozostałych przypadkach
bool handleMenuEvents(sf::RenderWindow& window, sf::Font& font, Settings& settings);

// Funkcja odpowiedzialna za wyświetlanie ekranu ustawień
void displaySettings(sf::RenderWindow& window, sf::Font& font, Settings& settings);

#endif
