#ifndef CHARACTER_SPRITES_H
#define CHARACTER_SPRITES_H

#include <SFML/Graphics.hpp>
#include <iostream>
#include <vector>
#include <cmath>

// Klasa bazowa dla wszystkich postaci
class CharacterSprite : public sf::Sprite
{
public:
    CharacterSprite(const std::string& path, float scale_x, float scale_y, const sf::Vector2f& origin)
    {
        if (!texture_.loadFromFile(path)) {
            std::cerr << "Could not load texture: " << path << std::endl;
        }
        setTexture(texture_);
        setScale(scale_x, scale_y);
        setOrigin(origin);
    }

    void animate(const sf::Time &elapsed)
    {
        float dt = elapsed.asSeconds();
        t_ += dt;

        if (t_ > 0.1f) {
            fragments_index++;
            t_ = 0.0f;
        }

        if (fragments_index >= rectVector.size()) {
            fragments_index = 0;
        }

        setTextureRect(rectVector[fragments_index]);
    }

    void add_animation_frame(const sf::IntRect& frame)
    {
        rectVector.push_back(frame);
    }

protected:
    sf::Texture texture_;
    float t_ = 0.0f;
    unsigned int fragments_index = 0;
    std::vector<sf::IntRect> rectVector;
};

// Klasa dla postaci Monstra
class MonsterSprite : public CharacterSprite
{
public:
    MonsterSprite(const std::string& path)
        : CharacterSprite(path, 3.0f, 3.0f, sf::Vector2f(10.0f, 10.0f))
    {
        setTextureRect(sf::IntRect(0, 0, 0, 0));
    }

    void setPlayerPosition(const sf::Vector2f& position)
    {
        playerPosition_ = position;
    }

    void followPlayer(float deltaTime)
    {
        sf::Vector2f currentPosition = getPosition();
        sf::Vector2f direction = playerPosition_ - currentPosition - sf::Vector2f(33, 42);
        float length = std::sqrt(direction.x * direction.x + direction.y * direction.y);
        if (length != 0) {
            direction /= length;
        }
        if (direction.x < 0) {
            setScale(-3, 3);
        }
        if (direction.x > 0) {
            setScale(3, 3);
        }

        sf::Vector2f newPosition = currentPosition + direction * speed * deltaTime;
        setPosition(newPosition);
    }

    void die_monster(const sf::Vector2f& playerPosition, float distance)
    {
        float angle = static_cast<float>(std::rand()) / static_cast<float>(RAND_MAX) * 2 * M_PI;
        float offsetX = std::cos(angle) * distance;
        float offsetY = std::sin(angle) * distance;
        sf::Vector2f newPosition = playerPosition + sf::Vector2f(offsetX, offsetY);
        setPosition(newPosition);
    }

private:
    float speed = 50.0f + static_cast<float>(rand()) / (static_cast<float>(RAND_MAX / (100.0f - 15.0f)));
    sf::Vector2f playerPosition_;
};

// Klasa dla postaci Bohatera
class HERO : public CharacterSprite
{
public:
    HERO(const std::string& path)
        : CharacterSprite(path, 2.0f, 2.0f, sf::Vector2f(15.0f, 15.0f))
    {
        setTextureRect(sf::IntRect(0, 0, 0, 0));
        setPosition(390, 290);
    }

    void animate_stand(const sf::Time &elapsed)
    {
        float dt = elapsed.asSeconds();
        t__stand += dt;

        if (t__stand > 0.3f) {
            fragments_index_stand++;
            t__stand = 0.0f;
        }
        if (fragments_index_stand >= rectVector_stand.size()) {
            fragments_index_stand = 0;
        }

        setTextureRect(rectVector_stand[fragments_index_stand]);
    }

    void add_animation_frame_stand(const sf::IntRect& frame)
    {
        rectVector_stand.push_back(frame);
    }

private:
    float t__stand = 0.0f;
    unsigned int fragments_index_stand = 0;
    std::vector<sf::IntRect> rectVector_stand;
};

// Klasa pochodna dla Bohatera z obsługą kolizji
class HeroSpriteWithCollision : public HERO
{
public:
    HeroSpriteWithCollision(const std::string& path)
        : HERO(path)
    {}

    void setBounds(int left, int right, int top, int bottom)
    {
        bound_top = top;
        bound_bottom = bottom;
        bound_right = right;
        bound_left = left;
    }

    bool Collision_T(sf::FloatRect wall_bounds, sf::FloatRect guy_bounds)
    {
        return (guy_bounds.top + guy_bounds.height >= wall_bounds.top - 3) &&
               (guy_bounds.top < wall_bounds.top) &&
               (guy_bounds.left + guy_bounds.width > wall_bounds.left + 3) &&
               (guy_bounds.left < wall_bounds.left + wall_bounds.width - 3);
    }

    bool Collision_L(sf::FloatRect wall_bounds, sf::FloatRect guy_bounds)
    {
        return (guy_bounds.left + guy_bounds.width >= wall_bounds.left - 3) &&
               (guy_bounds.left < wall_bounds.left) &&
               (guy_bounds.top + guy_bounds.height > wall_bounds.top + 3) &&
               (guy_bounds.top < wall_bounds.top + wall_bounds.height - 3);
    }

    bool Collision_B(sf::FloatRect wall_bounds, sf::FloatRect guy_bounds)
    {
        return (guy_bounds.top >= wall_bounds.top + wall_bounds.height - 3) &&
               (guy_bounds.top < wall_bounds.top + wall_bounds.height) &&
               (guy_bounds.left + guy_bounds.width > wall_bounds.left + 3) &&
               (guy_bounds.left < wall_bounds.left + wall_bounds.width - 3);
    }

    bool Collision_R(sf::FloatRect wall_bounds, sf::FloatRect guy_bounds)
    {
        return (guy_bounds.left >= wall_bounds.left + wall_bounds.width - 3) &&
               (guy_bounds.left < wall_bounds.left + wall_bounds.width) &&
               (guy_bounds.top + guy_bounds.height > wall_bounds.top + 3) &&
               (guy_bounds.top < wall_bounds.top + wall_bounds.height - 3);
    }

    void moveInDirection(const sf::Time &elapsed, const std::vector<sf::Sprite> &obstacles)
    {
        bool top = false, left = false, bottom = false, right = false;
        for (const auto &obstacle : obstacles) {
            sf::FloatRect rectangle_bounds = getGlobalBounds();
            sf::FloatRect wall_bounds = obstacle.getGlobalBounds();
            if (Collision_T(wall_bounds, rectangle_bounds)) {
                top = true;
            }
            if (Collision_L(wall_bounds, rectangle_bounds)) {
                left = true;
            }
            if (Collision_B(wall_bounds, rectangle_bounds)) {
                bottom = true;
            }
            if (Collision_R(wall_bounds, rectangle_bounds)) {
                right = true;
            }
        }

        float dt = elapsed.asSeconds();
        sf::FloatRect rectangle_bounds = getGlobalBounds();

        if ((!sf::Keyboard::isKeyPressed(sf::Keyboard::Right) &&
             !sf::Keyboard::isKeyPressed(sf::Keyboard::Left) &&
             !sf::Keyboard::isKeyPressed(sf::Keyboard::Up) &&
             !sf::Keyboard::isKeyPressed(sf::Keyboard::Down)) &&
            rectangle_bounds.left > bound_left && !right) {
            animate_stand(elapsed);
        }

        if (sf::Keyboard::isKeyPressed(sf::Keyboard::Up) &&
            rectangle_bounds.top > bound_top && !bottom) {
            move(m_speed_x * 0, m_speed_y * -dt);
            if (!sf::Keyboard::isKeyPressed(sf::Keyboard::Right) &&
                !sf::Keyboard::isKeyPressed(sf::Keyboard::Left) &&
                !sf::Keyboard::isKeyPressed(sf::Keyboard::Down)) {
                animate(elapsed);
            }
        }

        if (sf::Keyboard::isKeyPressed(sf::Keyboard::Down) &&
            rectangle_bounds.height + rectangle_bounds.top <= bound_bottom && !top) {
            move(m_speed_x * 0, m_speed_y * dt);
            if (!sf::Keyboard::isKeyPressed(sf::Keyboard::Right) &&
                !sf::Keyboard::isKeyPressed(sf::Keyboard::Left) &&
                !sf::Keyboard::isKeyPressed(sf::Keyboard::Up)) {
                animate(elapsed);
            }
        }

        if (sf::Keyboard::isKeyPressed(sf::Keyboard::Left) &&
            rectangle_bounds.left > bound_left && !right) {
            move(m_speed_x * -dt, m_speed_y * 0);
            if (!sf::Keyboard::isKeyPressed(sf::Keyboard::Right)) {
                animate(elapsed);
            }
            setScale(-2, 2);
        }

        if (sf::Keyboard::isKeyPressed(sf::Keyboard::Right) &&
            rectangle_bounds.width + rectangle_bounds.left <= bound_right && !left) {
            move(m_speed_x * dt, m_speed_y * 0);
            animate(elapsed);
            setScale(2, 2);
        }
    }

private:
    int m_speed_x = 200;
    int m_speed_y = 200;
    int bound_top = 0;
    int bound_bottom = 0;
    int bound_left = 0;
    int bound_right = 0;
};

#endif // CHARACTER_SPRITES_H
