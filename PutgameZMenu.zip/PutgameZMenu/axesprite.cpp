#include "AxeSprite.h"

AxeSprite::AxeSprite(const std::string& path) : Weapon(path) {
    setOrigin(400, 400);
    setScale(0.2f, 0.2f);
    activate();  // Axe is active by default
}
