#ifndef GAMERENDER_H
#define GAMERENDER_H
#include "monstersprite.h"

#include <SFML/Graphics.hpp>
#include "CharacterSprite.h"
#include "Weapon.h"
#include "livefunc.h"
#include "weaponsprite.h"
#include "axesprite.h"
#include "fireballsprite.h"
void renderGame(sf::RenderWindow& window, HeroSpriteWithCollision& guy, WeaponSprite& knife, AxeSprite& axe, FireballSprite& fireb, std::vector<sf::Sprite>& walls, std::vector<MonsterSprite>& sprites, std::vector<serce>& hearts, sf::Text& scoreText, sf::Text& ExitText, sf::Sprite& knifeIcon, sf::Text& knifeCooldownText);

#endif
