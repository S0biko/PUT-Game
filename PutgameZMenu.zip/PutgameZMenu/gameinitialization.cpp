#include "GameInitialization.h"
#include "Global.h"
#include <iostream>

void initializeGame(sf::RenderWindow& window, sf::Font& font, HeroSpriteWithCollision& guy, std::vector<sf::Sprite>& walls, std::vector<serce>& hearts, std::vector<MonsterSprite>& sprites, sf::Sprite& grass) {
    // Inicjalizacja tła, postaci, broni, potworów, zdrowia, itd.
    sf::Texture texture_wall;
    if (!texture_wall.loadFromFile(backgroundPhoto)) {
        std::cerr << "Failed to load background texture" << std::endl;
        return;
    }
    texture_wall.setRepeated(true);
    grass.setTexture(texture_wall);
    grass.setScale(1.5f, 1.5f);
    grass.setTextureRect(sf::IntRect(0, 0, 1500, 1500));

    guy = HeroSpriteWithCollision(characterPhoto);
    guy.add_animation_frame_stand(sf::IntRect(15, 6, 22, 30)); // hero standing frame 1
    guy.add_animation_frame_stand(sf::IntRect(65, 6, 22, 30)); // hero standing frame 2
    guy.add_animation_frame_stand(sf::IntRect(115, 6, 22, 30)); // hero standing frame 3
    guy.add_animation_frame(sf::IntRect(165, 6, 22, 30)); // hero running frame 1
    guy.add_animation_frame(sf::IntRect(215, 6, 22, 30)); // hero running frame 2
    guy.add_animation_frame(sf::IntRect(265, 6, 22, 30)); // hero running frame 3
    guy.add_animation_frame(sf::IntRect(315, 6, 22, 30)); // hero running frame 4
    guy.add_animation_frame(sf::IntRect(365, 6, 22, 30)); // hero running frame 5
    guy.add_animation_frame(sf::IntRect(415, 6, 22, 30)); // hero running frame 6

    // Inicjalizacja serc
    serce heart1(hearthPhoto);
    serce heart2(hearthPhoto);
    serce heart3(hearthPhoto);
    serce heart4(hearthPhoto);
    serce heart5(hearthPhoto);

    heart1.setPosition(600, 10);
    heart2.setPosition(630, 10);
    heart3.setPosition(660, 10);
    heart4.setPosition(690, 10);
    heart5.setPosition(720, 10);

    hearts.push_back(heart1);
    hearts.push_back(heart2);
    hearts.push_back(heart3);
    hearts.push_back(heart4);
    hearts.push_back(heart5);
}
