#include "game.h"
#include "GameInitialization.h"
#include "GameUpdate.h"
#include "GameRender.h"
#include "Global.h"
#include <iostream>

void runGame(sf::RenderWindow& window, sf::Font& font, const Settings& settings) {
    sf::Clock clock;

    HeroSpriteWithCollision guy(characterPhoto);
    std::vector<sf::Sprite> walls;
    std::vector<serce> hearts;
    std::vector<MonsterSprite> sprites;
    sf::Sprite grass;
    WeaponSprite knife(knifePhoto);
    AxeSprite axe(axePhoto);
    FireballSprite fireb(fireballPhoto);
    int Score = 0; // Deklaracja zmiennej Score

    initializeGame(window, font, guy, walls, hearts, sprites, grass);

    sf::Text scoreText;
    scoreText.setFont(font);
    scoreText.setCharacterSize(30);
    scoreText.setFillColor(sf::Color::White);
    scoreText.setPosition(340, 10);

    sf::Text ExitText;
    ExitText.setFont(font);
    ExitText.setCharacterSize(15);
    ExitText.setFillColor(sf::Color::White);
    ExitText.setPosition(20, 10);
    std::string exitString = "Press Esc to SHUTDOWN";

    sf::Texture knifeIconTexture;
    if (!knifeIconTexture.loadFromFile(knifePhoto)) {
        std::cerr << "Failed to load knife icon texture" << std::endl;
        return;
    }
    sf::Sprite knifeIcon(knifeIconTexture);
    knifeIcon.setScale(0.2f, 0.2f);
    knifeIcon.setPosition(950, 10);

    sf::Text knifeCooldownText;
    knifeCooldownText.setFont(font);
    knifeCooldownText.setCharacterSize(20);
    knifeCooldownText.setFillColor(sf::Color::White);
    knifeCooldownText.setPosition(970, 50);

    while (window.isOpen()) {
        sf::Time elapsed = clock.restart();

        // Aktualizacja gry
        updateGame(window, elapsed, guy, knife, axe, fireb, walls, sprites, hearts, Score, font, settings);

        // Renderowanie gry
        renderGame(window, guy, knife, axe, fireb, walls, sprites, hearts, scoreText, ExitText, knifeIcon, knifeCooldownText);
    }
}
