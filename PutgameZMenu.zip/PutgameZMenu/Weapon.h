#ifndef WEAPON_H
#define WEAPON_H

#include <SFML/Graphics.hpp>
#include <string>

class Weapon : public sf::Sprite {
private:
    bool active;

protected:
    sf::Texture texture;
    float speed_x, speed_y;

public:
    Weapon(const std::string& path);
    void setSpeed(float speedX, float speedY);
    void moveIt(const sf::Time &elapsed);
    bool isActive() const;
    void activate();
    void deactivate();
    virtual void update(const sf::Time& elapsed); // Dodajemy metodę update
};

#endif // WEAPON_H
