
#ifndef GLOBAL_H
#define GLOBAL_H

#include <string>

// Globalne zmienne przechowujące ścieżki do plików graficznych
const std::string hearthPhoto = "C:/QtPrograms/PutGame/PutGame/build/asstets/heart.png";
const std::string characterPhoto = "C:/QtPrograms/PutGame/PutGame/build/asstets/character.png";
const std::string zombiePhoto = "C:/QtPrograms/PutGame/PutGame/build/asstets/monster.png";
const std::string backgroundPhoto = "C:/QtPrograms/PutGame/PutGame/build/asstets/TILE_1G.png";
const std::string fireballPhoto = "C:/QtPrograms/PutGame/PutGame/build/asstets/fireball.png";
const std::string axePhoto = "C:/QtPrograms/PutGame/PutGame/build/asstets/axe.png";
const std::string knifePhoto = "C:/QtPrograms/PutGame/PutGame/build/asstets/knife.png";

#endif // GLOBAL_H
