#ifndef AXESPRITE_H
#define AXESPRITE_H

#include "Weapon.h"

class AxeSprite : public Weapon {
public:
    AxeSprite(const std::string& path);
};

#endif // AXESPRITE_H
