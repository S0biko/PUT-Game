#include "livefunc.h"
#include <iostream>
#include <string>

serce::serce(const std::string& path)
{
    if (!texture_.loadFromFile(path)) {
        std::cerr << "Could not load texture" << path << std::endl;
    }
    setTexture(texture_);
}
