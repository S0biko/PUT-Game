#include "WeaponSprite.h"

WeaponSprite::WeaponSprite(const std::string& path) : Weapon(path), throwCooldown(1.5f) {
    setScale(0.15f, -0.15f);
}

bool WeaponSprite::canThrowKnife() const {
    return throwClock.getElapsedTime().asSeconds() >= throwCooldown;
}

void WeaponSprite::resetThrowCooldown() {
    throwClock.restart();
}

float WeaponSprite::getCooldownRemaining() const {
    float remaining = throwCooldown - throwClock.getElapsedTime().asSeconds();
    return remaining > 0 ? remaining : 0;
}
