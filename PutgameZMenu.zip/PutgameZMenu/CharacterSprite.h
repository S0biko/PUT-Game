#ifndef CHARACTERSPRITE_H
#define CHARACTERSPRITE_H

#include <SFML/Graphics.hpp>
#include <vector>
#include "settings.h"
class HeroSpriteWithCollision : public sf::Sprite {
private:
    sf::Texture texture;
    std::vector<sf::IntRect> animationFramesStand;
    std::vector<sf::IntRect> animationFramesRun;
    float speed_x;
    float speed_y;

public:
    HeroSpriteWithCollision(const std::string& path);
    void add_animation_frame_stand(const sf::IntRect& frame);
    void add_animation_frame(const sf::IntRect& frame);
    void moveInDirection(const sf::Time& elapsed, const std::vector<sf::Sprite>& walls, const Settings& settings);
    void setBounds(int left, int right, int top, int bottom);
    void update(const sf::Time& elapsed); // Dodajemy metodę update
};

#endif // CHARACTERSPRITE_H
