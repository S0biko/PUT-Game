#ifndef GAME_H
#define GAME_H
#include "weaponsprite.h"
#include "axesprite.h"
#include "fireballsprite.h"
#include <SFML/Graphics.hpp>
#include "CharacterSprite.h"
#include "livefunc.h"
#include "settings.h"
#include "monstersprite.h"


#include <SFML/Graphics.hpp>
#include "settings.h"

// Deklaracje funkcji
void runGame(sf::RenderWindow& window, sf::Font& font, const Settings& settings);
void initializeGame(sf::RenderWindow& window, sf::Font& font, HeroSpriteWithCollision& guy, std::vector<sf::Sprite>& walls, std::vector<serce>& hearts, std::vector<MonsterSprite>& sprites, sf::Sprite& grass);
void updateGame(sf::RenderWindow& window, sf::Time elapsed, HeroSpriteWithCollision& guy, WeaponSprite& knife, AxeSprite& axe, FireballSprite& fireb, std::vector<sf::Sprite>& walls, std::vector<MonsterSprite>& sprites, std::vector<serce>& hearts, int& Score, sf::Font& font, const Settings& settings);
void renderGame(sf::RenderWindow& window, HeroSpriteWithCollision& guy, WeaponSprite& knife, AxeSprite& axe, FireballSprite& fireb, std::vector<sf::Sprite>& walls, std::vector<MonsterSprite>& sprites, std::vector<serce>& hearts, sf::Text& scoreText, sf::Text& ExitText, sf::Sprite& knifeIcon, sf::Text& knifeCooldownText);

#endif
