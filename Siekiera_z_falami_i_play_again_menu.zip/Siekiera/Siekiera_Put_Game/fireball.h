#ifndef FIREBALL_H
#define FIREBALL_H

#include "Weapon.h"

class Fireball : public Weapon
{
private:
    float t_ = 0.0f;
    std::vector<sf::IntRect> rectVector;
    unsigned int fragments_index = 0;
    float speed_x_fb = 100.0f; // Przykładowe wartości, możesz je zmienić
    float speed_y_fb = 100.0f;

public:
    Fireball(const std::string& path);
    void animate(const sf::Time &elapsed);
    void add_animation_frame(const sf::IntRect& frame);
    void MoveIt(const sf::Time &elapsed);
};

#endif // FIREBALL_H
