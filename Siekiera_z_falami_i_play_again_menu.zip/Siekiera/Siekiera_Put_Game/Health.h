#ifndef HEALTH_H
#define HEALTH_H


#include <SFML/Graphics.hpp>
#include <iostream>
#include <string>

class Serce : public sf::Sprite
{
public:
    Serce(const std::string& path)
    {
        if (!texture_.loadFromFile(path)) {
            std::cerr << "Could not load texture: " << path << std::endl;
        }
        setTexture(texture_);
    }

private:
    sf::Texture texture_;
};


#endif // HEALTH_H
