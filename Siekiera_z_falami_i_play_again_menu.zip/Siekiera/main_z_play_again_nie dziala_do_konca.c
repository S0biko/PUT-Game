#include <iostream>
#include <vector>
#include <cmath>
#include <cstdlib>
#include <SFML/Window.hpp>
#include <SFML/Graphics.hpp>
// Funkcje globalne
#include <Global.h>
// Funkcje Postaci
#include <CharacterSprite.h>
// Funkcje broni
#include "Weapon.h"
#include "Knife.h"
#include "Fireball.h"
#include "Axe.h"
// Inne funkcje
#include <livefunc.h>
#include <Health.h>
#include <string>

void runHealthExample();

void Game_over(int wynik, bool& playAgain) {
    sf::RenderWindow window_over(sf::VideoMode(500, 500), "Game over");
    std::string fontPhoto = "C:/Users/Bartek/Desktop/PutGameZMenu_umnie/Minecraft.ttf";
    sf::Font font;
    if (!font.loadFromFile(fontPhoto)) {
        std::cerr << "Could not load font: " << fontPhoto << std::endl;
        return;
    }

    sf::Text title("Game over", font, 50);
    title.setFillColor(sf::Color::White);
    title.setPosition(120, 100);

    std::string napis = "Twoj wynik to " + std::to_string(wynik);
    sf::Text wynik_napis(napis, font, 30);
    wynik_napis.setFillColor(sf::Color::White);
    wynik_napis.setPosition(120, 200);

    sf::Text playAgainText("Play Again", font, 30);
    playAgainText.setFillColor(sf::Color::White);
    playAgainText.setPosition(180, 300);

    while (window_over.isOpen())
    {
        sf::Event event;
        while (window_over.pollEvent(event))
        {
            if (event.type == sf::Event::Closed)
            {
                window_over.close();
            }

            if (event.type == sf::Event::MouseButtonPressed) {
                sf::Vector2i mousePos = sf::Mouse::getPosition(window_over);
                if (mousePos.x >= 180 && mousePos.x <= 320 &&
                    mousePos.y >= 300 && mousePos.y <= 330) {
                    playAgain = true;
                    window_over.close();
                }
            }
        }

        window_over.clear();
        window_over.draw(title);
        window_over.draw(wynik_napis);
        window_over.draw(playAgainText);
        window_over.display();
    }
}


// __________________________________Obrysy_____________________
void displayBoundingBox(const sf::Sprite& sprite, sf::RenderWindow& window)
{
    sf::FloatRect bounds = sprite.getGlobalBounds();

    sf::RectangleShape boundingBox;
    boundingBox.setSize(sf::Vector2f(bounds.width, bounds.height));
    boundingBox.setOutlineThickness(2.f);
    boundingBox.setOutlineColor(sf::Color::Blue);
    boundingBox.setFillColor(sf::Color::Transparent);
    boundingBox.setPosition(bounds.left, bounds.top);

    // window.draw(boundingBox);
}

// _____________________________MAIN_________________________________________
int main()
{
    bool playAgain = false;

    do {
        playAgain = false;

        sf::RenderWindow window(sf::VideoMode(windowX, windowY), "PutGame");
        sf::Clock clock;

        // �adowanie tekstury �ciany
        sf::Texture texture_wall;
        if (!texture_wall.loadFromFile(backgroundPhoto)) {
            std::cerr << "Could not load texture: " << backgroundPhoto << std::endl;
            return 1;
        }
        texture_wall.setRepeated(true);

        // �adowanie tekstury no�a
        sf::Texture knife_texture;
        if (!knife_texture.loadFromFile(knifePhoto)) {
            std::cerr << "Could not load texture: " << knifePhoto << std::endl;
            return 1;
        } else {
            std::cout << "Knife texture loaded successfully." << std::endl;
        }

        // �adowanie tekstury siekiery
        sf::Texture axe_texture;
        if (!axe_texture.loadFromFile(axePhoto)) {
            std::cerr << "Could not load texture: " << axePhoto << std::endl;
            return 1;
        } else {
            std::cout << "Axe texture loaded successfully." << std::endl;
        }

        sf::Font font;
        if (!font.loadFromFile(fontPhoto)) {
            // Error handling - Failed to load the font
            return 1;
        }

        HeroSpriteWithCollision guy(characterPhoto);
        guy.add_animation_frame_stand(sf::IntRect(15, 6, 22, 30)); // hero standing frame 1
        guy.add_animation_frame_stand(sf::IntRect(65, 6, 22, 30)); // hero standing frame 2
        guy.add_animation_frame_stand(sf::IntRect(115, 6, 22, 30)); // hero standing frame 3
        guy.add_animation_frame(sf::IntRect(165, 6, 22, 30)); // hero running frame 1
        guy.add_animation_frame(sf::IntRect(215, 6, 22, 30)); // hero running frame 2
        guy.add_animation_frame(sf::IntRect(265, 6, 22, 30)); // hero running frame 3
        guy.add_animation_frame(sf::IntRect(315, 6, 22, 30)); // hero running frame 4
        guy.add_animation_frame(sf::IntRect(365, 6, 22, 30)); // hero running frame 5
        guy.add_animation_frame(sf::IntRect(415, 6, 22, 30)); // hero running frame 6

        guy.setBounds(0, window.getSize().x, 0, window.getSize().y);

        std::cout << "Window size: " << window.getSize().x << ", " << window.getSize().y << std::endl;
        std::cout << "Main function - Bounds after setting texture rect: " << guy.getGlobalBounds().left << ", " << guy.getGlobalBounds().top << ", "
                  << guy.getGlobalBounds().width << ", " << guy.getGlobalBounds().height << std::endl;

        sf::Sprite grass;
        grass.setTexture(texture_wall);
        grass.setScale(1.5, 1.5);
        grass.setTextureRect(sf::IntRect(0, 0, 1500, 1500));
        std::vector<sf::Sprite> walls;

        bool IsFireb = false;

        std::vector<Knife> knives;
        for (int i = 0; i < 10; ++i) {
            Knife knife(knifePhoto);
            knife.setTexture(knife_texture);
            knives.push_back(knife);
        }

        Axe axe(axePhoto, sf::Vector2f(780, 10), window, font);
        axe.setTexture(axe_texture);

        Fireball fireb(fireballPhoto);
        fireb.add_animation_frame(sf::IntRect(40, 68, 400, 400));
        fireb.add_animation_frame(sf::IntRect(540, 68, 400, 400));
        fireb.add_animation_frame(sf::IntRect(1040, 68, 400, 400));
        fireb.add_animation_frame(sf::IntRect(1540, 68, 400, 400));
        fireb.add_animation_frame(sf::IntRect(2040, 68, 400, 400));
        fireb.add_animation_frame(sf::IntRect(2540, 68, 400, 400));

        MonsterSprite zombie(zombiePhoto);
        zombie.add_animation_frame(sf::IntRect(5, 70, 26, 29));
        zombie.add_animation_frame(sf::IntRect(35, 70, 26, 29));
        zombie.add_animation_frame(sf::IntRect(66, 70, 26, 29));
        zombie.add_animation_frame(sf::IntRect(100, 70, 26, 29));
        zombie.add_animation_frame(sf::IntRect(133, 70, 26, 29));
        zombie.add_animation_frame(sf::IntRect(166, 70, 26, 29));
        zombie.add_animation_frame(sf::IntRect(196, 70, 26, 29));
        std::vector<MonsterSprite> sprites;

        std::vector<serce> hearts;
        serce heart1(hearthPhoto);
        serce heart2(hearthPhoto);
        serce heart3(hearthPhoto);
        serce heart4(hearthPhoto);
        serce heart5(hearthPhoto);

        heart1.setPosition(600, 10);
        heart2.setPosition(630, 10);
        heart3.setPosition(660, 10);
        heart4.setPosition(690, 10);
        heart5.setPosition(720, 10);

        hearts.push_back(heart1);
        hearts.push_back(heart2);
        hearts.push_back(heart3);
        hearts.push_back(heart4);
        hearts.push_back(heart5);

        sf::Text scoreText;
        scoreText.setFont(font);
        scoreText.setCharacterSize(30);
        scoreText.setFillColor(sf::Color::White);
        scoreText.setPosition(340, 10);

        sf::Text exitText;
        exitText.setFont(font);
        exitText.setCharacterSize(15);
        exitText.setFillColor(sf::Color::White);
        exitText.setPosition(20, 10);
        std::string exitString = "Press Esc to SHUTDOWN";

        while (window.isOpen())
        {
            sf::Time elapsed = clock.restart();

            float dt = elapsed.asSeconds();
            static float counter_fireb = 0;
            static float counter_knife = 0;
            static float counter = 0;
            static float counter_lives = 0;
            static float counter_fireb_max = 0;

            counter += dt;
            counter_fireb += dt;
            counter_knife += dt;
            counter_lives += dt;
            counter_fireb_max += dt;

            if (counter > 1.0) {
                sprites.push_back(zombie);
                zombie.die_monster(guy.getPosition(), 600);
                counter = 0;
            }

            if (counter_fireb > 3.0 && !IsFireb) {
                fireb.setScale(0.2, 0.2);
                float angle = static_cast<float>(std::rand()) / static_cast<float>(RAND_MAX) * 2 * M_PI;
                IsFireb = true;
                counter_fireb = 0;
                fireb.setPosition(guy.getPosition());
                speed_x_fb = 250 * cos(angle);
                speed_y_fb = 250 * sin(angle);
                float rotation = std::atan2(sin(angle), cos(angle)) * 180.f / static_cast<float>(M_PI);
                fireb.setRotation(rotation);
            }

            if (counter_fireb_max > 5.0) {
                IsFireb = false;
                counter_fireb_max = 0;
            }

            if (counter_knife > 0.5) {
                for (auto& knife : knives) {
                    knife.resetPosition(guy.getPosition());
                    knife.setDirection(guy.getDirection());
                }
                counter_knife = 0;
            }

            sf::Event event;
            while (window.pollEvent(event))
            {
                if (event.type == sf::Event::Closed)
                {
                    std::cout << "Closing Window" << std::endl;
                    Game_over(Score, playAgain);
                    window.close();
                }
                if (event.type == sf::Event::KeyPressed && event.key.code == sf::Keyboard::Escape)
                {
                    std::cout << "Closing Window" << std::endl;
                    Game_over(Score, playAgain);
                    window.close();
                }
                if (event.type == sf::Event::KeyPressed && event.key.code == sf::Keyboard::E)
                {
                    axe.activate();
                }
                if (event.type == sf::Event::KeyPressed && event.key.code == sf::Keyboard::Space)
                {
                    Knife knife(knifePhoto);
                    knife.setTexture(knife_texture);
                    knife.setPosition(guy.getPosition());
                    knife.setDirection(guy.getDirection());
                    knives.push_back(knife);
                    std::cout << "Knife thrown! Position: " << knife.getPosition().x << ", " << knife.getPosition().y << std::endl;
                }
            }

            sf::FloatRect guy_bounds = guy.getGlobalBounds();
            bool currentIntersection = false;

            sf::Vector2f position;
            sf::FloatRect fireball_bounds = fireb.getGlobalBounds();

            for (auto& knife : knives)
            {
                knife.MoveIt(elapsed);
            }

            for (auto& knife : knives) {
                sf::Vector2f knife_pos = knife.getPosition();
                if (knife_pos.x < 0.f || knife_pos.y < 0.f || knife_pos.x > window.getSize().x || knife_pos.y > window.getSize().y) {
                    knife.resetPosition(guy.getPosition());
                }
            }

            guy.setBounds(0, window.getSize().x, 0, window.getSize().y);
            guy.moveInDirection(elapsed, walls);

            window.clear(sf::Color::Black);
            window.draw(grass);
            window.draw(guy);
            for (auto &heart : hearts)
            {
                window.draw(heart);
            }

            for (auto& knife : knives)
            {
                window.draw(knife);
                displayBoundingBox(knife, window);
            }

            fireb.MoveIt(elapsed);
            fireb.animate(elapsed);

            if (IsFireb)
            {
                window.draw(fireb);
            }

            axe.update(elapsed, guy.getPosition());

            displayBoundingBox(guy, window);
            displayBoundingBox(fireb, window);
            displayBoundingBox(axe, window);

            for (auto& sprite : sprites)
            {
                sf::FloatRect monster_bounds = sprite.getGlobalBounds();
                if (monster_bounds.intersects(guy_bounds) && counter_lives > 1.0)
                {
                    currentIntersection = true;
                    counter_lives = 0;
                }

                if (currentIntersection && !intersectionOccurred)
                {
                    intersectionOccurred = true;

                    if (healthEnd < healthVar)
                    {
                        hearts[healthEnd].setScale(0, 0);
                        healthEnd++;
                    }

                    if (healthEnd == healthVar)
                    {
                        std::cout << "Twoj wynik to: " << Score << " ";
                        Game_over(Score, playAgain);
                        window.close();
                    }
                }
                else if (!currentIntersection)
                {
                    intersectionOccurred = false;
                }

                for (auto& knife : knives)
                {
                    sf::FloatRect knife_bounds = knife.getGlobalBounds();
                    if (monster_bounds.intersects(knife_bounds))
                    {
                        Score += knifeScore;
                        sprite.die_monster(guy.getPosition(), 400);
                        knife.setPosition(-100, -100);
                    }
                }

                if (monster_bounds.intersects(fireball_bounds))
                {
                    Score += fireballScore;
                    sprite.die_monster(guy.getPosition(), 400);
                }

                if (monster_bounds.intersects(axe.getGlobalBounds()))
                {
                    Score += axeScore;
                    sprite.die_monster(guy.getPosition(), 400);
                }

                sprite.setPlayerPosition(guy.getPosition());
                sprite.followPlayer(dt);
                sprite.animate(elapsed);
                displayBoundingBox(sprite, window);
                window.draw(sprite);
            }

            std::string scoreString = "Wynik: " + std::to_string(Score);
            scoreText.setString(scoreString);
            window.draw(scoreText);

            exitText.setString(exitString);
            window.draw(exitText);

            window.display();
        }

    } while (playAgain);

    return 0;
}
